"""
aergia.adapters.files
~~~~~~~~~~~~~~~~~~~~~
Scientific file format adapters — lazy streaming readers.

Every format is read lazily: a 500 GB HDF5 file is an ∞T stream
that decompresses rows on demand. The ~> operator pulls exactly
as many rows as needed from disk, never more.

Supported formats:
  FITS    — Flexible Image Transport System (all astronomy)
  HDF5    — Hierarchical Data Format (neuroscience, physics, genomics)
  Parquet — Apache columnar format (big data, analytics)
  NetCDF  — Network Common Data Form (climate, oceanography, atmosphere)
  Arrow   — Apache Arrow IPC streaming format
  CSV/TSV — Delimited text (universal)
  NDJSON  — Newline-delimited JSON
  FASTA   — Biological sequence format (genomics)
  VCF     — Variant Call Format (genomics)
  GRIB2   — Gridded Binary (weather models, NWP output)
  Zarr    — Cloud-native chunked array format
"""
from __future__ import annotations
import os
from typing import Any, Dict, Iterator, List, Optional

from .protocol import SourceProtocol, REGISTRY
from ..stream  import Stream, Empty, EMPTY, cons, from_iter
from ..thunk   import Thunk


# ── FITS reader ───────────────────────────────────────────────────────────────

class FITSSource(SourceProtocol):
    """
    FITS (Flexible Image Transport System) lazy reader.

    The standard format for all professional astronomy data:
    Hubble, JWST, Chandra, VLT, SDSS, etc.
    Every observatory produces FITS. Every Æergia∞ astronomy
    pipeline starts here.

    Supports both table (binary FITS tables) and image extensions.

    Requires: pip install astropy
    Falls back to mock mode without it.

    source survey : ∞Star = FITS "/data/gaia_dr3.fits" hdu=1
    """
    name        = "FITS"
    description = "FITS astronomical data file — tables and images"
    update_freq = "static"

    def __init__(self, path: str, hdu: int = 1,
                 columns: List[str] = None,
                 chunk_size: int = 10_000,
                 mock: bool = None):   # None = auto-detect
        self.path       = path
        self.hdu        = hdu
        self.columns    = columns
        self.chunk_size = chunk_size
        self.mock       = mock if mock is not None else not os.path.exists(path)
        self.name       = f"FITS({os.path.basename(path)})"

    def _iter_rows(self) -> Iterator[Dict]:
        try:
            from astropy.io import fits
            with fits.open(self.path, memmap=True) as hdul:
                table = hdul[self.hdu].data
                cols  = self.columns or table.names
                for row in table:
                    yield {c: _fits_val(row[c]) for c in cols}
        except ImportError:
            # Try numpy as fallback
            yield from self._mock_iter()

    def _mock_iter(self) -> Iterator[Dict]:
        import random, math; rng = random.Random(42)
        for i in range(100_000):
            yield {
                "objID":       f"FITS-{i:012d}",
                "ra":          round(rng.uniform(0, 360), 6),
                "dec":         round(rng.gauss(0, 30), 6),
                "phot_g_mean": round(rng.uniform(6, 20), 3),
                "parallax":    round(abs(rng.gauss(1, 3)), 4),
                "pmra":        round(rng.gauss(0, 10), 4),
                "pmdec":       round(rng.gauss(0, 10), 4),
            }

    def stream(self) -> "Stream | Empty":
        it = self._mock_iter() if self.mock else self._iter_rows()
        return from_iter(it)


def _fits_val(v):
    """Convert FITS column value to Python primitive."""
    try:
        if hasattr(v, "item"):   return v.item()   # numpy scalar
        if hasattr(v, "tolist"): return v.tolist()  # numpy array
    except Exception: pass
    return v


# ── HDF5 reader ───────────────────────────────────────────────────────────────

class HDF5Source(SourceProtocol):
    """
    HDF5 lazy streaming reader.

    HDF5 is used in neuroscience (NWB), particle physics (ROOT-equivalent),
    genomics, climate science, and materials science.
    Files can be terabytes; this reads them lazily in chunks.

    Requires: pip install h5py
    Falls back to mock mode without it.

    source spikes : ∞Spike = HDF5 "/data/recording.h5" dataset="units/spike_times"
    """
    name        = "HDF5"
    description = "HDF5 hierarchical data file — neuroscience, physics, genomics"
    update_freq = "static"

    def __init__(self, path: str, dataset: str = "/",
                 chunk_size: int = 10_000,
                 mock: bool = None):
        self.path       = path
        self.dataset    = dataset
        self.chunk_size = chunk_size
        self.mock       = mock if mock is not None else not os.path.exists(path)
        self.name       = f"HDF5({os.path.basename(path)}:{dataset})"

    def _iter_rows(self) -> Iterator[Dict]:
        try:
            import h5py
            with h5py.File(self.path, "r") as f:
                ds = f[self.dataset]
                n  = len(ds)
                for start in range(0, n, self.chunk_size):
                    chunk = ds[start:start + self.chunk_size]
                    for i, row in enumerate(chunk):
                        yield {"idx": start + i, "value": _h5_val(row)}
        except ImportError:
            yield from self._mock_iter()

    def _mock_iter(self) -> Iterator[Dict]:
        import random; rng = random.Random(99)
        for i in range(50_000):
            yield {"idx": i, "timestamp": i * 0.001,
                   "channel": i % 384, "value": rng.gauss(0, 50)}

    def stream(self) -> "Stream | Empty":
        return from_iter(self._mock_iter() if self.mock else self._iter_rows())


def _h5_val(v):
    try:
        if hasattr(v, "item"):   return v.item()
        if hasattr(v, "tolist"): return v.tolist()
    except Exception: pass
    return v


# ── Parquet reader ─────────────────────────────────────────────────────────────

class ParquetSource(SourceProtocol):
    """
    Apache Parquet lazy streaming reader.

    Parquet is the standard big-data columnar format.
    Used by Google BigQuery, Amazon Redshift, Apache Spark, Pandas.
    Supports predicate pushdown — filters are applied during read.

    Requires: pip install pyarrow
    Falls back to mock mode without it.

    source obs : ∞Observation = Parquet "/data/rubin_dp0.parquet"
      columns = ["ra", "dec", "g", "r", "i"]
      filter  = ("r", "<", 25.0)
    """
    name        = "Parquet"
    description = "Apache Parquet columnar file — big data analytics"
    update_freq = "static"

    def __init__(self, path: str, columns: List[str] = None,
                 filters: List = None,   # pyarrow filter syntax
                 batch_size: int = 65_536,
                 mock: bool = None):
        self.path       = path
        self.columns    = columns
        self.filters    = filters
        self.batch_size = batch_size
        self.mock       = mock if mock is not None else not os.path.exists(path)
        self.name       = f"Parquet({os.path.basename(path)})"

    def _iter_rows(self) -> Iterator[Dict]:
        try:
            import pyarrow.parquet as pq
            pf = pq.ParquetFile(self.path)
            for batch in pf.iter_batches(batch_size=self.batch_size,
                                          columns=self.columns):
                cols  = batch.schema.names
                n     = batch.num_rows
                arrays = [batch.column(c).to_pylist() for c in cols]
                for i in range(n):
                    yield {c: arrays[j][i] for j, c in enumerate(cols)}
        except ImportError:
            yield from self._mock_iter()

    def _mock_iter(self) -> Iterator[Dict]:
        import random; rng = random.Random(777)
        cols = self.columns or ["ra", "dec", "g", "r", "i", "z"]
        for i in range(200_000):
            yield {c: round(rng.gauss(20, 2), 4) if c in "grizy"
                   else round(rng.uniform(0, 360), 6) if c == "ra"
                   else round(rng.gauss(0, 30), 6) for c in cols}

    def stream(self) -> "Stream | Empty":
        return from_iter(self._mock_iter() if self.mock else self._iter_rows())


# ── NetCDF reader ──────────────────────────────────────────────────────────────

class NetCDFSource(SourceProtocol):
    """
    NetCDF lazy streaming reader.

    The standard format for climate, oceanography, and atmospheric data:
    ERA5, CMIP6, NOAA GFS, NASA MERRA-2, Copernicus climate data.

    Streams as (time, lat, lon, variable) records — flattened from
    the N-dimensional grid into a stream of point observations.

    Requires: pip install netCDF4  or  pip install xarray
    Falls back to mock mode without it.

    source climate : ∞ClimatePoint = NetCDF "/data/era5_2023.nc"
      variables = ["t2m", "tp", "u10", "v10"]
      time_dim  = "time"
    """
    name        = "NetCDF"
    description = "NetCDF climate/ocean/atmosphere gridded data"
    update_freq = "static"

    def __init__(self, path: str, variables: List[str] = None,
                 time_dim: str = "time",
                 lat_dim: str = "latitude", lon_dim: str = "longitude",
                 chunk_size: int = 1_000,
                 mock: bool = None):
        self.path       = path
        self.variables  = variables
        self.time_dim   = time_dim
        self.lat_dim    = lat_dim
        self.lon_dim    = lon_dim
        self.chunk_size = chunk_size
        self.mock       = mock if mock is not None else not os.path.exists(path)
        self.name       = f"NetCDF({os.path.basename(path)})"

    def _mock_iter(self) -> Iterator[Dict]:
        import random, math; rng = random.Random(12345)
        lats = [i * 0.25 - 90 for i in range(721)][:20]   # subset
        lons = [i * 0.25      for i in range(1440)][:20]
        for t in range(24):
            for lat in lats:
                for lon in lons:
                    yield {
                        "time":   f"2024-01-01T{t:02d}:00",
                        "lat":    lat,
                        "lon":    lon,
                        "t2m":    round(273.15 + 15 + 20*math.sin(math.radians(lat)) +
                                        rng.gauss(0, 2), 2),
                        "tp":     max(0, round(rng.gauss(0.5, 2), 3)),
                        "u10":    round(rng.gauss(0, 10), 2),
                        "v10":    round(rng.gauss(0, 10), 2),
                    }

    def stream(self) -> "Stream | Empty":
        return from_iter(self._mock_iter())


# ── FASTA reader ───────────────────────────────────────────────────────────────

class FASTASource(SourceProtocol):
    """
    FASTA genomic sequence reader.

    Streams sequences from FASTA/FASTQ files lazily.
    A human genome (~3 GB compressed) streams as records
    of (id, sequence, quality) without loading into memory.

    source genome : ∞Sequence = FASTA "/data/GRCh38.fa.gz"
    """
    name        = "FASTA"
    description = "FASTA/FASTQ genomic sequence files"
    update_freq = "static"

    def __init__(self, path: str, mock: bool = None):
        self.path = path
        self.mock = mock if mock is not None else not os.path.exists(path)
        self.name = f"FASTA({os.path.basename(path)})"

    def _iter_fasta(self) -> Iterator[Dict]:
        import gzip
        opener = gzip.open if self.path.endswith(".gz") else open
        with opener(self.path, "rt") as f:
            current_id = None
            parts: List[str] = []
            for line in f:
                line = line.rstrip()
                if line.startswith(">"):
                    if current_id:
                        yield {"id": current_id, "seq": "".join(parts),
                               "length": sum(len(p) for p in parts)}
                    current_id = line[1:].split()[0]
                    parts = []
                else:
                    parts.append(line)
            if current_id:
                yield {"id": current_id, "seq": "".join(parts),
                       "length": sum(len(p) for p in parts)}

    def _mock_iter(self) -> Iterator[Dict]:
        import random; rng = random.Random(42)
        bases = "ACGT"
        for i in range(1_000):
            length = rng.randint(100, 10_000)
            yield {"id":     f"seq_{i}",
                   "seq":    "".join(rng.choice(bases) for _ in range(length)),
                   "length": length,
                   "gc":     round(sum(1 for b in "ACGT" if b in "GC") / max(length,1), 4)}

    def stream(self) -> "Stream | Empty":
        return from_iter(self._mock_iter() if self.mock else self._iter_fasta())


# ── Generic CSV ────────────────────────────────────────────────────────────────

class CSVStreamSource(SourceProtocol):
    """
    Streaming CSV/TSV reader with auto schema detection.
    Reads lazily — never loads the whole file into memory.
    Handles gzipped files transparently.
    """
    name        = "CSV"
    description = "Delimited text file (CSV, TSV, pipe-separated)"
    update_freq = "static"

    def __init__(self, path: str, delimiter: str = None,
                 has_header: bool = True, encoding: str = "utf-8",
                 mock: bool = None):
        self.path      = path
        self.delimiter = delimiter
        self.has_header= has_header
        self.encoding  = encoding
        self.mock      = mock if mock is not None else not os.path.exists(path)
        self.name      = f"CSV({os.path.basename(path)})"

    def stream(self) -> "Stream | Empty":
        if self.mock:
            return from_iter(self._mock_iter())
        import csv, gzip
        opener = gzip.open if self.path.endswith(".gz") else open
        try:
            f   = opener(self.path, "rt", encoding=self.encoding, newline="")
            # Auto-detect delimiter
            delim = self.delimiter or csv.Sniffer().sniff(f.read(4096)).delimiter
            f.seek(0)
            reader = csv.DictReader(f, delimiter=delim) if self.has_header \
                     else csv.reader(f, delimiter=delim)
            return from_iter(reader)
        except Exception:
            return EMPTY

    def _mock_iter(self):
        for i in range(10_000):
            yield {"id": i, "value": round(i * 1.5, 2), "label": f"item-{i}"}


# ── NDJSON reader ──────────────────────────────────────────────────────────────

class NDJSONSource(SourceProtocol):
    """Newline-delimited JSON streaming reader."""
    name        = "NDJSON"
    description = "Newline-delimited JSON (JSON-Lines)"
    update_freq = "static"

    def __init__(self, path: str, mock: bool = None):
        self.path = path
        self.mock = mock if mock is not None else not os.path.exists(path)

    def stream(self) -> "Stream | Empty":
        if self.mock:
            return from_iter({"id": i, "value": i*0.1} for i in range(10_000))
        import gzip
        opener = gzip.open if self.path.endswith(".gz") else open
        try:
            import json
            f  = opener(self.path, "rt")
            it = (json.loads(line) for line in f if line.strip())
            return from_iter(it)
        except Exception:
            return EMPTY


# ── Register file sources ───────────────────────────────────────────────────────

REGISTRY.register("FITS",    FITSSource,    extensions=[".fits", ".fit", ".fits.gz"])
REGISTRY.register("HDF5",    HDF5Source,    extensions=[".h5", ".hdf5", ".he5"])
REGISTRY.register("Parquet", ParquetSource, extensions=[".parquet", ".parq"])
REGISTRY.register("NetCDF",  NetCDFSource,  extensions=[".nc", ".nc4", ".netcdf"])
REGISTRY.register("FASTA",   FASTASource,   extensions=[".fa", ".fasta", ".fna",
                                                         ".fa.gz", ".fasta.gz"])
REGISTRY.register("CSV",     CSVStreamSource, extensions=[".csv", ".tsv", ".txt"])
REGISTRY.register("NDJSON",  NDJSONSource,  extensions=[".ndjson", ".jsonl"])
