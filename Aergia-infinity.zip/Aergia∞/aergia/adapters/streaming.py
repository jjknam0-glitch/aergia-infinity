"""
aergia.adapters.streaming
~~~~~~~~~~~~~~~~~~~~~~~~~
Real-time streaming protocol adapters.

WebSocket  — live market data, telescope pipelines, IoT gateways
Kafka      — distributed event streams, telescope pipelines (LSST, SKA)
MQTT       — IoT sensors, weather stations, satellite telemetry
SSE        — Server-Sent Events, GitHub events, live APIs

All produce the same ∞T stream interface. The ~> demand operator
works identically whether the source is a file or a live WebSocket.

Key difference from REST: streaming sources are PUSH-based.
The runtime pulls from an internal buffer that the source fills
asynchronously. The buffer is lazy — it never grows unboundedly.

Usage:
  source ligo_live : ∞Strain = WebSocket "wss://gracedb.ligo.org/stream"
  source market    : ∞Tick   = Kafka "kafka://broker:9092/market-ticks"
  source sensors   : ∞Reading = MQTT "mqtt://broker/sensors/temperature/#"
"""
from __future__ import annotations
import json
import queue
import threading
import time
from typing import Any, Callable, Dict, Optional

from .protocol import SourceProtocol, REGISTRY
from ..stream  import Stream, Empty, EMPTY, cons
from ..thunk   import Thunk


# ── Shared buffer-based stream ─────────────────────────────────────────────────

class BufferedStream:
    """
    Thread-safe buffer between a push producer (WebSocket/Kafka/MQTT)
    and the pull consumer (the ~> demand operator).

    The buffer is bounded — if the consumer can't keep up, backpressure
    is applied to the producer (or records are dropped with warning).
    """
    def __init__(self, maxsize: int = 10_000,
                 on_overflow: str = "block"):   # "block" | "drop" | "error"
        self._q         = queue.Queue(maxsize)
        self._done      = threading.Event()
        self.on_overflow= on_overflow
        self.dropped    = 0

    def put(self, record: Any, timeout: float = 5.0) -> bool:
        """Called by the producer thread."""
        try:
            if self.on_overflow == "block":
                self._q.put(record, timeout=timeout)
                return True
            else:
                self._q.put_nowait(record)
                return True
        except queue.Full:
            if self.on_overflow == "drop":
                self.dropped += 1
                return False
            raise

    def done(self):
        """Signal that the producer is finished."""
        self._done.set()

    def to_stream(self) -> "Stream | Empty":
        """Convert buffer to a lazy Æergia∞ stream."""
        def go() -> "Stream | Empty":
            while True:
                try:
                    record = self._q.get(timeout=0.1)
                    return cons(record, Thunk(go))
                except queue.Empty:
                    if self._done.is_set() and self._q.empty():
                        return EMPTY
                    continue
        return go()


# ── WebSocket source ───────────────────────────────────────────────────────────

class WebSocketSource(SourceProtocol):
    """
    Live WebSocket stream.

    Connects in a background thread, parses JSON messages,
    and feeds them into a BufferedStream for lazy consumption.

    source gravityWaves : ∞Event = WebSocket "wss://gracedb.ligo.org/stream"

    Supported message formats:
      - JSON objects          → dict per message
      - JSON arrays           → one record per array element
      - Newline-delimited JSON → one record per line
    """
    name        = "WebSocket"
    description = "Live WebSocket JSON stream"
    update_freq = "realtime"

    def __init__(self, url: str,
                 headers: Dict[str, str] = None,
                 transform: Optional[Callable] = None,
                 buffer_size: int = 10_000,
                 reconnect: bool = True,
                 reconnect_delay: float = 5.0,
                 ping_interval: float = 30.0,
                 mock: bool = True,         # mock by default (no ws library needed)
                 mock_rate: float = 1.0,    # records per second in mock mode
                 mock_gen: Optional[Callable] = None):
        self.url            = url
        self.headers        = headers or {}
        self.transform      = transform
        self.buffer_size    = buffer_size
        self.reconnect      = reconnect
        self.reconnect_delay= reconnect_delay
        self.ping_interval  = ping_interval
        self.mock           = mock
        self.mock_rate      = mock_rate
        self.mock_gen       = mock_gen or self._default_mock_gen
        self.name           = f"WebSocket({url})"

    @staticmethod
    def _default_mock_gen():
        """Default mock: simple counter with timestamp."""
        import time, random
        rng = random.Random()
        i   = 0
        while True:
            yield {
                "seq":       i,
                "timestamp": time.time(),
                "value":     rng.gauss(0, 1),
                "channel":   rng.choice(["H1", "L1", "V1"]),
            }
            i += 1

    @classmethod
    def from_url(cls, url: str, **kwargs) -> "WebSocketSource":
        return cls(url, **kwargs)

    def stream(self) -> "Stream | Empty":
        buf = BufferedStream(self.buffer_size)

        if self.mock:
            return self._mock_stream()

        def producer():
            try:
                import websocket   # pip install websocket-client
                def on_message(ws, message):
                    try:
                        data = json.loads(message)
                        if isinstance(data, list):
                            for r in data: buf.put(self.transform(r) if self.transform else r)
                        else:
                            buf.put(self.transform(data) if self.transform else data)
                    except Exception: pass

                def on_error(ws, err):
                    if self.reconnect:
                        time.sleep(self.reconnect_delay)
                        ws.run_forever(ping_interval=self.ping_interval)

                def on_close(ws, code, msg):
                    if not self.reconnect:
                        buf.done()

                ws = websocket.WebSocketApp(
                    self.url,
                    header=list(f"{k}: {v}" for k,v in self.headers.items()),
                    on_message=on_message,
                    on_error=on_error,
                    on_close=on_close,
                )
                ws.run_forever(ping_interval=self.ping_interval)
            except ImportError:
                return self._mock_stream()
            except Exception:
                buf.done()

        t = threading.Thread(target=producer, daemon=True)
        t.start()
        return buf.to_stream()

    def _mock_stream(self) -> "Stream | Empty":
        gen = self.mock_gen()
        delay = 1.0 / self.mock_rate if self.mock_rate > 0 else 0
        def go():
            record = next(gen)
            if delay > 0:
                time.sleep(delay)
            return cons(record, Thunk(go))
        return go()


# ── Kafka source ───────────────────────────────────────────────────────────────

class KafkaSource(SourceProtocol):
    """
    Apache Kafka consumer as an infinite lazy stream.

    Kafka is the backbone of real-time scientific data pipelines:
      - LSST (Vera Rubin Observatory) → 10M alerts/night via Kafka
      - SKA telescope → Kafka-based visibility stream
      - CERN ALICE → collision event stream via Kafka

    Requires: pip install kafka-python
    Falls back to mock mode without it.

    source events : ∞Alert = Kafka "kafka://broker:9092/lsst.alerts"
    """
    name        = "Kafka"
    description = "Apache Kafka topic — distributed event stream"
    update_freq = "realtime"

    def __init__(self, brokers: str, topic: str,
                 group_id: str = "aergia-consumer",
                 auto_offset: str = "earliest",
                 transform: Optional[Callable] = None,
                 buffer_size: int = 50_000,
                 mock: bool = True,
                 mock_rate: float = 100.0):
        self.brokers     = brokers if isinstance(brokers, list) else [brokers]
        self.topic       = topic
        self.group_id    = group_id
        self.auto_offset = auto_offset
        self.transform   = transform
        self.buffer_size = buffer_size
        self.mock        = mock
        self.mock_rate   = mock_rate
        self.name        = f"Kafka({topic})"

    @classmethod
    def from_url(cls, url: str, **kwargs) -> "KafkaSource":
        # kafka://broker1:9092,broker2:9092/topic-name
        rest = url.replace("kafka://", "")
        if "/" in rest:
            brokers_str, topic = rest.rsplit("/", 1)
        else:
            brokers_str, topic = rest, "default"
        return cls(brokers_str.split(","), topic, **kwargs)

    def stream(self) -> "Stream | Empty":
        if self.mock:
            return self._mock_stream()
        buf = BufferedStream(self.buffer_size, on_overflow="drop")
        def producer():
            try:
                from kafka import KafkaConsumer
                consumer = KafkaConsumer(
                    self.topic,
                    bootstrap_servers=self.brokers,
                    group_id=self.group_id,
                    auto_offset_reset=self.auto_offset,
                    value_deserializer=lambda m: json.loads(m.decode("utf-8")),
                )
                for msg in consumer:
                    record = self.transform(msg.value) if self.transform else msg.value
                    base = record if isinstance(record, dict) else {"value": record}
                    buf.put({**base, "_offset": msg.offset, "_partition": msg.partition, "_timestamp": msg.timestamp})
            except ImportError:
                for record in self._mock_gen():
                    buf.put(record)
            except Exception:
                buf.done()
        t = threading.Thread(target=producer, daemon=True)
        t.start()
        return buf.to_stream()

    def _mock_gen(self):
        import random; rng = random.Random(); i = 0
        delay = 1.0 / self.mock_rate if self.mock_rate > 0 else 0
        while True:
            yield {"offset": i, "key": f"key-{i}", "value": rng.random(),
                   "timestamp": time.time(), "topic": self.topic}
            i += 1
            if delay: time.sleep(delay)

    def _mock_stream(self) -> "Stream | Empty":
        gen = self._mock_gen()
        def go(): return cons(next(gen), Thunk(go))
        return go()

    def checkpoint(self) -> Optional[str]:
        return json.dumps({"brokers": self.brokers, "topic": self.topic,
                           "offset": "latest"})


# ── MQTT source ────────────────────────────────────────────────────────────────

class MQTTSource(SourceProtocol):
    """
    MQTT subscriber as an infinite lazy stream.

    MQTT is the protocol of IoT — weather stations, telescopes,
    satellite telemetry, industrial sensors.

    Requires: pip install paho-mqtt
    Falls back to mock mode without it.

    source sensors : ∞Reading = MQTT "mqtt://broker/sensors/#"
    """
    name        = "MQTT"
    description = "MQTT topic subscription — IoT sensor streams"
    update_freq = "realtime"

    def __init__(self, broker: str, port: int = 1883,
                 topic: str = "#",
                 username: str = None, password: str = None,
                 qos: int = 0,
                 transform: Optional[Callable] = None,
                 buffer_size: int = 10_000,
                 mock: bool = True):
        self.broker    = broker
        self.port      = port
        self.topic     = topic
        self.username  = username
        self.password  = password
        self.qos       = qos
        self.transform = transform
        self.buf_size  = buffer_size
        self.mock      = mock
        self.name      = f"MQTT({broker}/{topic})"

    @classmethod
    def from_url(cls, url: str, **kwargs) -> "MQTTSource":
        rest = url.replace("mqtt://", "").replace("mqtts://", "")
        if "/" in rest:
            broker, topic = rest.split("/", 1)
        else:
            broker, topic = rest, "#"
        host, port = (broker.split(":") + ["1883"])[:2]
        return cls(host, int(port), topic, **kwargs)

    def stream(self) -> "Stream | Empty":
        if self.mock:
            return self._mock_stream()
        buf = BufferedStream(self.buf_size, on_overflow="drop")
        def producer():
            try:
                import paho.mqtt.client as mqtt
                def on_message(client, userdata, msg):
                    try:
                        payload = json.loads(msg.payload.decode())
                        record = self.transform(payload) if self.transform else payload
                        extra = record if isinstance(record, dict) else {"value": record}
                        buf.put({"topic": msg.topic, "qos": msg.qos, "retain": msg.retain, **extra})
                    except Exception: pass
                client = mqtt.Client()
                if self.username: client.username_pw_set(self.username, self.password)
                client.on_message = on_message
                client.connect(self.broker, self.port, 60)
                client.subscribe(self.topic, self.qos)
                client.loop_forever()
            except ImportError:
                pass
        t = threading.Thread(target=producer, daemon=True)
        t.start()
        return buf.to_stream()

    def _mock_stream(self) -> "Stream | Empty":
        import random, math; rng = random.Random(); i = 0
        def go():
            nonlocal i
            record = {
                "topic":       f"sensors/node{rng.randint(1,20)}/temperature",
                "seq":         i,
                "timestamp":   time.time(),
                "temperature": round(20 + 5*math.sin(i/100) + rng.gauss(0,0.5), 2),
                "humidity":    round(60 + 10*math.cos(i/80) + rng.gauss(0,1), 1),
                "pressure":    round(1013 + rng.gauss(0, 5), 1),
            }
            i += 1
            time.sleep(0.01)   # 100 msg/s mock rate
            return cons(record, Thunk(go))
        return go()


# ── Server-Sent Events source ──────────────────────────────────────────────────

class SSESource(SourceProtocol):
    """
    Server-Sent Events (SSE) stream.
    Used by GitHub Events API, many live data services.
    """
    name        = "SSE"
    description = "Server-Sent Events live stream"
    update_freq = "realtime"

    def __init__(self, url: str, headers: Dict = None,
                 transform: Optional[Callable] = None,
                 mock: bool = True):
        self.url       = url
        self.headers   = headers or {}
        self.transform = transform
        self.mock      = mock

    def stream(self) -> "Stream | Empty":
        if self.mock:
            import random; rng = random.Random()
            def go(i=0):
                record = {"event": "data", "seq": i, "value": rng.random()}
                time.sleep(0.1)
                return cons(record, Thunk(lambda i=i: go(i+1)))
            return go()
        buf = BufferedStream(5_000)
        def producer():
            import urllib.request
            try:
                req = urllib.request.Request(self.url,
                    headers={"Accept": "text/event-stream", **self.headers})
                with urllib.request.urlopen(req, timeout=None) as r:
                    current = {}
                    for raw_line in r:
                        line = raw_line.decode("utf-8").rstrip()
                        if not line:
                            if current:
                                record = self.transform(current) if self.transform else current
                                buf.put(record)
                                current = {}
                        elif line.startswith("data:"):
                            try: current["data"] = json.loads(line[5:].strip())
                            except: current["data"] = line[5:].strip()
                        elif ":" in line:
                            k, v = line.split(":", 1)
                            current[k.strip()] = v.strip()
            except Exception:
                buf.done()
        t = threading.Thread(target=producer, daemon=True)
        t.start()
        return buf.to_stream()


# ── Register streaming sources ─────────────────────────────────────────────────

REGISTRY.register("WebSocket", WebSocketSource,
    url_patterns=["ws://", "wss://"])
REGISTRY.register("Kafka", KafkaSource,
    url_patterns=["kafka://"])
REGISTRY.register("MQTT", MQTTSource,
    url_patterns=["mqtt://", "mqtts://"])
REGISTRY.register("SSE", SSESource,
    url_patterns=["text/event-stream"])
