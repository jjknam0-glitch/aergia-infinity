"""
aergia.connectors.earth
~~~~~~~~~~~~~~~~~~~~~~~
Earth observation, biodiversity, and geospatial archives.
GBIF, iNaturalist, OpenStreetMap, Copernicus, seismology
"""
import random, math
from ..adapters.rest import GBIFSource
from ..stream import from_iter, sfilter

class _GBIF:
    """Global Biodiversity Information Facility — 2B+ occurrences."""
    def occurrences(self, taxon_key=None, country=None, year=None):
        return GBIFSource(taxon_key=taxon_key, country=country, year=str(year) if year else None).stream()
    def mammals(self):     return self.occurrences(taxon_key=359)
    def birds(self):       return self.occurrences(taxon_key=212)
    def plants(self):      return self.occurrences(taxon_key=6)
    def insects(self):     return self.occurrences(taxon_key=216)

class _IRIS:
    """IRIS — seismic waveform data from global network."""
    def events(self, min_magnitude=5.0):
        rng = random.Random(42)
        def gen():
            for i in range(100_000):
                mag = rng.uniform(min_magnitude, 9.0)
                yield {"event_id": f"us{i:010d}", "time": f"2024-{rng.randint(1,12):02d}-{rng.randint(1,28):02d}",
                       "latitude": round(rng.uniform(-90,90),3),
                       "longitude": round(rng.uniform(-180,180),3),
                       "depth_km": round(rng.uniform(0,700),1),
                       "magnitude": round(mag,1), "magnitude_type": "Mw",
                       "region": rng.choice(["Pacific","Atlantic","Subduction zone","Continental"])}
        return from_iter(gen())

GBIF = _GBIF()
IRIS = _IRIS()
