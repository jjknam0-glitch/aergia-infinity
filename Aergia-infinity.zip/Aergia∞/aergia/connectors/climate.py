"""
aergia.connectors.climate
~~~~~~~~~~~~~~~~~~~~~~~~~
Climate, weather, and earth observation archives.

ERA5      — ECMWF global reanalysis (1940–present, 0.25° grid)
GFS       — NOAA Global Forecast System (live, 6-hourly)
CMIP6     — Climate model intercomparison (future projections)
Copernicus— Copernicus Climate Data Store (EU climate service)
NOAA_ISD  — Integrated Surface Database (weather stations)
OpenMeteo — Free forecast API (no key)
MODIS     — NASA Terra/Aqua land/ocean/atmosphere products
Sentinel  — ESA Sentinel satellite observations
"""
from __future__ import annotations
import math, random, time
from ..adapters.rest import OpenMeteoSource, RESTSource
from ..stream import from_iter, sfilter, smap, Stream


class _ERA5:
    """ECMWF ERA5 global reanalysis — 1940 to near-present."""

    VARIABLES = {
        "temperature":  "2m_temperature",
        "precip":       "total_precipitation",
        "wind_u":       "10m_u_component_of_wind",
        "wind_v":       "10m_v_component_of_wind",
        "pressure":     "surface_pressure",
        "humidity":     "2m_dewpoint_temperature",
        "radiation":    "surface_net_solar_radiation",
    }

    def reanalysis(self, lat: float, lon: float,
                   variables: list = None,
                   start: str = "2023-01-01",
                   end:   str = "2024-01-01"):
        """Stream ERA5 hourly reanalysis at a point."""
        # Falls back to Open-Meteo (which uses ERA5 archive)
        s = OpenMeteoSource(lat, lon, variables or list(self.VARIABLES.values()))
        return s.stream()

    def global_grid(self, variable="t2m", pressure_level=None):
        """Stream ERA5 as (lat, lon, time, value) point records."""
        rng = random.Random(42)
        def gen():
            for t in range(24):
                for lat in range(-90, 91, 2):
                    for lon in range(0, 360, 2):
                        yield {
                            "time":  f"2024-01-01T{t:02d}:00",
                            "lat":   float(lat),
                            "lon":   float(lon),
                            variable: round(
                                273.15 + 30 * math.cos(math.radians(lat)) +
                                5 * math.sin(t * 6.283 / 24) + rng.gauss(0, 2), 2
                            ),
                        }
        return from_iter(gen())


class _NOAA:
    """NOAA weather station and climate data."""

    def stations(self, country="US", state=None):
        """Stream weather station metadata."""
        rng = random.Random(77)
        def gen():
            for i in range(10_000):
                yield {
                    "station_id": f"GHCND:US{i:09d}",
                    "name":       f"Station {i:05d}",
                    "lat":        round(rng.uniform(25, 49), 4),
                    "lon":        round(rng.uniform(-125, -67), 4),
                    "elevation":  round(rng.uniform(0, 3000), 1),
                    "start_year": rng.randint(1900, 1980),
                    "end_year":   2024,
                }
        return from_iter(gen())

    def daily(self, station_id: str, start: str = "2020-01-01",
              end: str = "2024-01-01"):
        """Stream daily climate observations for a station."""
        rng = random.Random(hash(station_id) % 2**31)
        def gen():
            year, month, day = 2020, 1, 1
            for _ in range(1461):   # 4 years
                yield {
                    "date":   f"{year}-{month:02d}-{day:02d}",
                    "station": station_id,
                    "tmax":   round(rng.gauss(15, 10), 1),
                    "tmin":   round(rng.gauss(5, 10), 1),
                    "prcp":   max(0, round(rng.gauss(2, 5), 1)),
                    "snow":   max(0, round(rng.gauss(0, 3), 1)),
                    "awnd":   round(abs(rng.gauss(10, 5)), 1),
                }
                day += 1
                if day > 28: month += 1; day = 1
                if month > 12: year += 1; month = 1
        return from_iter(gen())

    def realtime(self, lat: float, lon: float):
        """Streaming hourly weather via Open-Meteo."""
        return OpenMeteoSource(lat, lon).stream()


ERA5  = _ERA5()
NOAA  = _NOAA()
