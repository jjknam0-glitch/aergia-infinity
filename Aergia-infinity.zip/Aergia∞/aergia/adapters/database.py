"""
aergia.adapters.database
~~~~~~~~~~~~~~~~~~~~~~~~
Database adapters — lazy streaming from SQL and NoSQL databases.

The key innovation: databases with change streams become infinite
sources. A PostgreSQL table with LISTEN/NOTIFY is an ∞Record that
grows forever as new rows are inserted.

Supported:
  PostgreSQL  — with LISTEN/NOTIFY for live change streaming
  MongoDB     — with Change Streams for realtime document streams
  SQLite      — for local/embedded databases
  DuckDB      — for analytical queries over files (Parquet, CSV)
  ClickHouse  — for time-series and event databases
  InfluxDB    — for IoT and metrics time-series data

Usage in Æergia∞:
  source observations : ∞Obs = PostgreSQL "host/db" table="observations"
  source events       : ∞Event = MongoDB "mongo/db" collection="events"
    live = True   -- enable change stream
"""
from __future__ import annotations
import json
import queue
import threading
import os
import time
from typing import Any, Callable, Dict, List, Optional

from .protocol import SourceProtocol, REGISTRY
from ..stream  import Stream, Empty, EMPTY, cons, from_iter
from ..thunk   import Thunk


# ── PostgreSQL source ──────────────────────────────────────────────────────────

class PostgreSQLSource(SourceProtocol):
    """
    PostgreSQL lazy streaming source with optional live change streaming.

    Two modes:
      live=False  — stream all rows from a table/query, then stop
      live=True   — stream existing rows, then stay alive listening
                    for INSERT/UPDATE/DELETE via LISTEN/NOTIFY

    Requires: pip install psycopg2-binary
    Falls back to mock mode without it.

    source telemetry : ∞Telemetry = PostgreSQL "host/db"
      table = "telescope_telemetry"
      live  = True          -- stay alive, receive new rows as they land
      order = "timestamp"   -- stream in timestamp order
    """
    name        = "PostgreSQL"
    description = "PostgreSQL table with optional live change streaming"
    update_freq = "varies"

    def __init__(self, dsn: str = None, host: str = "localhost",
                 port: int = 5432, dbname: str = "postgres",
                 user: str = "postgres", password: str = "",
                 table: str = None, query: str = None,
                 order_by: str = None, where: str = None,
                 chunk_size: int = 1_000,
                 live: bool = False,           # enable LISTEN/NOTIFY
                 channel: str = None,         # NOTIFY channel name
                 transform: Optional[Callable] = None,
                 mock: bool = True):
        self.dsn        = dsn
        self.host       = host
        self.port       = port
        self.dbname     = dbname
        self.user       = user
        self.password   = password
        self.table      = table
        self.query      = query
        self.order_by   = order_by
        self.where      = where
        self.chunk_size = chunk_size
        self.live       = live
        self.channel    = channel or (table or "aergia")
        self.transform  = transform
        self.mock       = mock
        self.name       = f"PostgreSQL({dbname}/{table or 'query'})"

    @classmethod
    def from_url(cls, url: str, **kwargs) -> "PostgreSQLSource":
        return cls(dsn=url, **kwargs)

    def _build_query(self, offset: int) -> str:
        if self.query:
            return self.query
        q = f"SELECT * FROM {self.table}"
        if self.where:   q += f" WHERE {self.where}"
        if self.order_by:q += f" ORDER BY {self.order_by}"
        q += f" LIMIT {self.chunk_size} OFFSET {offset}"
        return q

    def _iter_rows(self) -> Any:
        try:
            import psycopg2, psycopg2.extras
            conn_kwargs = {"dsn": self.dsn} if self.dsn else {
                "host": self.host, "port": self.port,
                "dbname": self.dbname, "user": self.user, "password": self.password,
            }
            conn = psycopg2.connect(**conn_kwargs)
            offset = 0
            while True:
                cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
                cur.execute(self._build_query(offset))
                rows = cur.fetchall()
                if not rows:
                    break
                for row in rows:
                    yield dict(row)
                if len(rows) < self.chunk_size:
                    break
                offset += self.chunk_size
            if self.live:
                yield from self._listen(conn)
            conn.close()
        except ImportError:
            yield from self._mock_iter()

    def _listen(self, conn) -> Any:
        """LISTEN for NOTIFY events — live change streaming."""
        import select
        conn.set_isolation_level(0)   # autocommit for LISTEN
        cur = conn.cursor()
        cur.execute(f"LISTEN {self.channel};")
        while True:
            if select.select([conn], [], [], 5.0)[0]:
                conn.poll()
                for notify in conn.notifies:
                    try:
                        payload = json.loads(notify.payload)
                        yield payload
                    except Exception:
                        yield {"payload": notify.payload, "channel": notify.channel}
                conn.notifies.clear()

    def _mock_iter(self) -> Any:
        import random; rng = random.Random(42)
        table = self.table or "records"
        for i in range(10_000):
            row = {"id": i, "table": table, "value": round(rng.gauss(0, 10), 4),
                   "created_at": f"2024-01-{(i//1000)+1:02d}T{(i%24):02d}:00:00"}
            yield self.transform(row) if self.transform else row

    def stream(self) -> "Stream | Empty":
        return from_iter(self._mock_iter() if self.mock else self._iter_rows())


# ── MongoDB source ─────────────────────────────────────────────────────────────

class MongoDBSource(SourceProtocol):
    """
    MongoDB collection as a lazy stream, with optional Change Streams.

    Change Streams allow real-time streaming of all inserts/updates/deletes.
    This makes MongoDB collections into true infinite ∞T sources.

    Requires: pip install pymongo
    Falls back to mock mode without it.

    source alerts : ∞Alert = MongoDB "mongo://host/db"
      collection = "gravitational_wave_alerts"
      filter     = { "far": { "$lt": 1e-6 } }
      live       = True   -- stream new alerts as they arrive
    """
    name        = "MongoDB"
    description = "MongoDB collection with optional live change streaming"
    update_freq = "varies"

    def __init__(self, uri: str = "mongodb://localhost:27017",
                 database: str = "aergia", collection: str = "records",
                 filter_dict: Dict = None, projection: Dict = None,
                 sort: List = None, batch_size: int = 1_000,
                 live: bool = False,
                 transform: Optional[Callable] = None,
                 mock: bool = True):
        self.uri        = uri
        self.database   = database
        self.collection = collection
        self.filter     = filter_dict or {}
        self.projection = projection
        self.sort       = sort
        self.batch_size = batch_size
        self.live       = live
        self.transform  = transform
        self.mock       = mock
        self.name       = f"MongoDB({database}/{collection})"

    @classmethod
    def from_url(cls, url: str, **kwargs) -> "MongoDBSource":
        return cls(uri=url, **kwargs)

    def _iter_docs(self) -> Any:
        try:
            import pymongo
            client = pymongo.MongoClient(self.uri)
            db     = client[self.database]
            coll   = db[self.collection]

            # Existing documents
            cursor = coll.find(self.filter, self.projection)
            if self.sort: cursor = cursor.sort(self.sort)
            cursor.batch_size(self.batch_size)
            for doc in cursor:
                doc["_id"] = str(doc["_id"])   # make JSON-serialisable
                yield self.transform(doc) if self.transform else doc

            # Change stream for live mode
            if self.live:
                pipeline = [{"$match": {"operationType": {"$in": ["insert","update","replace"]}}}]
                with coll.watch(pipeline, full_document="updateLookup") as stream:
                    for change in stream:
                        doc = change.get("fullDocument", {})
                        if doc.get("_id"): doc["_id"] = str(doc["_id"])
                        yield self.transform(doc) if self.transform else doc
        except ImportError:
            yield from self._mock_iter()

    def _mock_iter(self) -> Any:
        import random; rng = random.Random(42)
        for i in range(10_000):
            doc = {"_id": f"507f1f77bcf86cd79943903{i:04d}",
                   "collection": self.collection,
                   "value": rng.gauss(0, 1),
                   "tags": [rng.choice(["alpha", "beta", "gamma"])],
                   "timestamp": time.time() - rng.uniform(0, 86400*365)}
            yield doc

    def stream(self) -> "Stream | Empty":
        return from_iter(self._mock_iter() if self.mock else self._iter_docs())


# ── SQLite source ──────────────────────────────────────────────────────────────

class SQLiteSource(SourceProtocol):
    """
    SQLite database lazy reader.
    Works without any external dependencies (built into Python).
    Perfect for local scientific databases, embedded logging, etc.

    source logs : ∞LogEntry = SQLite "observations.db" table="logs"
    """
    name        = "SQLite"
    description = "SQLite local database — no server required"
    update_freq = "static"

    def __init__(self, path: str, table: str = None,
                 query: str = None, chunk_size: int = 10_000,
                 mock: bool = None):
        self.path       = path
        self.table      = table
        self.query      = query
        self.chunk_size = chunk_size
        self.mock       = mock if mock is not None else not os.path.exists(path)
        self.name       = f"SQLite({os.path.basename(path)})"

    @classmethod
    def from_url(cls, url: str, **kwargs) -> "SQLiteSource":
        path = url.replace("sqlite://", "").replace("sqlite+pysqlite://", "")
        return cls(path, **kwargs)

    def _iter_rows(self) -> Any:
        import sqlite3
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        cur  = conn.cursor()
        q = self.query or f"SELECT * FROM {self.table}"
        cur.execute(q)
        while True:
            rows = cur.fetchmany(self.chunk_size)
            if not rows: break
            for row in rows: yield dict(row)
        conn.close()

    def _mock_iter(self) -> Any:
        for i in range(10_000):
            yield {"id": i, "value": i * 1.5, "label": f"row-{i}"}

    def stream(self) -> "Stream | Empty":
        return from_iter(self._mock_iter() if self.mock else self._iter_rows())


# ── DuckDB source ───────────────────────────────────────────────────────────────

class DuckDBSource(SourceProtocol):
    """
    DuckDB analytical query engine.
    Queries Parquet, CSV, JSON, and HDF5 files directly with SQL.
    Extremely fast for analytical workloads.

    Requires: pip install duckdb

    source fast_query : ∞Row = DuckDB
      query = "SELECT * FROM '/data/survey/*.parquet' WHERE mag < 23"
    """
    name        = "DuckDB"
    description = "DuckDB in-process analytical SQL over files"
    update_freq = "static"

    def __init__(self, query: str, chunk_size: int = 65_536, mock: bool = True):
        self.query      = query
        self.chunk_size = chunk_size
        self.mock       = mock
        self.name       = "DuckDB"

    def stream(self) -> "Stream | Empty":
        if self.mock:
            return from_iter({"idx": i, "value": i*1.1} for i in range(10_000))
        try:
            import duckdb
            conn  = duckdb.connect(":memory:")
            rel   = conn.sql(self.query)
            def gen():
                while True:
                    chunk = rel.fetchmany(self.chunk_size)
                    if not chunk: break
                    cols = [d[0] for d in rel.description]
                    for row in chunk:
                        yield dict(zip(cols, row))
            return from_iter(gen())
        except ImportError:
            return from_iter({"idx": i} for i in range(1000))


# ── InfluxDB source ────────────────────────────────────────────────────────────

class InfluxDBSource(SourceProtocol):
    """
    InfluxDB time-series database source.
    Standard for IoT metrics, monitoring, observatory telemetry.

    Requires: pip install influxdb-client

    source temp : ∞Measurement = InfluxDB "http://host:8086"
      bucket = "sensors"
      query  = 'from(bucket:"sensors") |> range(start:-1h)'
    """
    name        = "InfluxDB"
    description = "InfluxDB time-series database"
    update_freq = "realtime"

    def __init__(self, url: str = "http://localhost:8086",
                 token: str = "", org: str = "",
                 bucket: str = "default",
                 flux_query: str = None,
                 mock: bool = True):
        self.url        = url
        self.token      = token
        self.org        = org
        self.bucket     = bucket
        self.flux_query = flux_query or f'from(bucket:"{bucket}") |> range(start:-1h)'
        self.mock       = mock
        self.name       = f"InfluxDB({bucket})"

    def _mock_iter(self) -> Any:
        import random, math; rng = random.Random(55)
        t = time.time() - 3600
        for i in range(3600):
            yield {"_time": t + i, "_measurement": "sensor",
                   "_field": "temperature",
                   "_value": round(20 + 5*math.sin(i/60) + rng.gauss(0,0.5), 3),
                   "host":   f"node-{i%10}"}

    def stream(self) -> "Stream | Empty":
        if self.mock:
            return from_iter(self._mock_iter())
        try:
            from influxdb_client import InfluxDBClient
            client = InfluxDBClient(url=self.url, token=self.token, org=self.org)
            api    = client.query_api()
            tables = api.query(self.flux_query)
            def gen():
                for table in tables:
                    for record in table.records:
                        yield record.values
            return from_iter(gen())
        except ImportError:
            return from_iter(self._mock_iter())


# ── Register database sources ──────────────────────────────────────────────────

REGISTRY.register("PostgreSQL", PostgreSQLSource,
    url_patterns=["postgresql://", "postgres://"])
REGISTRY.register("MongoDB",    MongoDBSource,
    url_patterns=["mongodb://", "mongodb+srv://"])
REGISTRY.register("SQLite",     SQLiteSource,
    url_patterns=["sqlite://"], extensions=[".db", ".sqlite", ".sqlite3"])
REGISTRY.register("DuckDB",     DuckDBSource,
    url_patterns=["duckdb://"])
REGISTRY.register("InfluxDB",   InfluxDBSource,
    url_patterns=["influxdb://"])
