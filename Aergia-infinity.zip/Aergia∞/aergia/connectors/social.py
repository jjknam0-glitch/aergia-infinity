"""
aergia.connectors.social
~~~~~~~~~~~~~~~~~~~~~~~~
Open academic and social data archives.
OpenAlex papers, arXiv, Wikipedia, GitHub, Reddit (Pushshift)
"""
import random
from ..adapters.rest import OpenAlexSource, ArXivSource, GitHubSource
from ..stream import from_iter, sfilter, smap

class _OpenAlex:
    """OpenAlex — 200M+ scholarly works, fully open."""
    def papers(self, year=None, field=None):
        f = []
        if year:  f.append(f"publication_year:{year}")
        if field: f.append(f"concepts.display_name:{field}")
        return OpenAlexSource(filter_str=",".join(f) if f else "").stream()

    def recent(self, days=30):
        return OpenAlexSource(filter_str=f"from_publication_date:2024-01-01",
                              sort="publication_date:desc").stream()

    def highly_cited(self, min_citations=100):
        from ..stream import sfilter
        return sfilter(lambda p: p.get("cited_by_count",0) >= min_citations,
                       self.papers())

class _ArXiv:
    """arXiv preprints — physics, math, CS, bio, econ."""
    def preprints(self, category="astro-ph.GA"):
        return ArXivSource(category=category).stream()
    def cs(self, subcategory="LG"):   return self.preprints(f"cs.{subcategory}")
    def physics(self, sub="hep-ph"):  return self.preprints(sub)
    def math(self, sub="CO"):         return self.preprints(f"math.{sub}")
    def bio(self, sub="NC"):          return self.preprints(f"q-bio.{sub}")

OpenAlex = _OpenAlex()
ArXiv    = _ArXiv()
