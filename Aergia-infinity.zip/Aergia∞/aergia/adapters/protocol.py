"""
aergia.adapters.protocol
~~~~~~~~~~~~~~~~~~~~~~~~
The universal Source protocol for Æergia∞.

Every data source in the known universe — REST APIs, WebSockets,
Kafka topics, PostgreSQL tables, FITS files, HDF5 datasets,
Parquet partitions, NetCDF grids, MQTT topics — exposes the
same interface: a lazy, infinite (or finite) Stream of records.

The ~> demand operator works identically regardless of whether
the source is:
  - A live WebSocket from a gravitational wave detector
  - A paginated REST API returning JSON
  - A Kafka topic receiving 1M events/second
  - A 500 GB HDF5 file on disk
  - A PostgreSQL table with LISTEN/NOTIFY change streaming
  - A FITS file from the Hubble archive

Key protocol methods:
  stream()       → ∞T    lazy stream of records (required)
  schema()       → dict  auto-detected field types (optional)
  checkpoint()   → str   resumable position marker (optional)
  resume(cp)     → ∞T    restart from checkpoint (optional)
  count()        → int   estimate of total records (optional, may be ∞)
  metadata()     → dict  source description, update frequency, etc.
"""
from __future__ import annotations
import time
from typing import Any, Dict, Iterator, Optional
from ..stream import Stream, Empty, EMPTY, cons, from_iter
from ..thunk  import Thunk


class SourceProtocol:
    """
    Universal source protocol.

    All data sources in Æergia∞ inherit from this class.
    The only required method is stream().

    source name : ∞T = SomeSource(...)
    """
    # Subclasses set these
    name:        str  = "UnknownSource"
    description: str  = ""
    update_freq: str  = "unknown"   # e.g. "realtime", "daily", "static"
    record_type: str  = "dict"

    def stream(self) -> "Stream | Empty":
        """Return the lazy infinite stream. REQUIRED."""
        raise NotImplementedError

    def schema(self) -> Dict[str, str]:
        """
        Auto-detect and return field types from the first record.
        Returns {field_name: type_string}.
        """
        try:
            first = self._peek_first()
            if first is None:
                return {}
            return {k: _infer_type(v) for k, v in first.items()
                    if not callable(v)}
        except Exception:
            return {}

    def checkpoint(self) -> Optional[str]:
        """
        Return a serialisable position marker for the current stream head.
        Implement in sources that support resumption (Kafka, databases, etc.)
        """
        return None

    def resume(self, checkpoint: str) -> "Stream | Empty":
        """
        Return a stream starting from the given checkpoint.
        Default: restart from beginning.
        """
        return self.stream()

    def count(self) -> Optional[int]:
        """
        Estimate total record count. Return None if infinite or unknown.
        """
        return None

    def metadata(self) -> Dict[str, Any]:
        """Source description and provenance information."""
        return {
            "name":        self.name,
            "description": self.description,
            "update_freq": self.update_freq,
            "record_type": self.record_type,
            "count":       self.count(),
            "schema":      self.schema(),
        }

    def _peek_first(self) -> Optional[Dict]:
        """Peek at the first record without consuming the stream."""
        from ..stream import take
        records = take(1, self.stream())
        return records[0] if records else None

    def __repr__(self) -> str:
        return f"∞Source({self.name})"

    # Convenience: make sources directly iterable
    def __iter__(self) -> Iterator:
        from ..stream import take
        s = self.stream()
        while not isinstance(s, Empty):
            yield s.head
            s = s.tail


def _infer_type(val: Any) -> str:
    if isinstance(val, bool):   return "Bool"
    if isinstance(val, int):    return "Int"
    if isinstance(val, float):  return "Float"
    if isinstance(val, str):    return "String"
    if isinstance(val, list):   return f"[{_infer_type(val[0]) if val else 'a'}]"
    if isinstance(val, dict):   return "Record"
    if isinstance(val, Thunk):  return "~a"
    return type(val).__name__


class SourceRegistry:
    """
    Global registry of all available data sources.
    Supports auto-detection from URL patterns and file extensions.
    """
    _sources: Dict[str, type] = {}
    _url_patterns: list = []         # [(pattern, source_class)]
    _file_extensions: Dict[str, type] = {}

    @classmethod
    def register(cls, name: str, source_class: type,
                 url_patterns: list = None,
                 extensions: list = None) -> None:
        cls._sources[name] = source_class
        if url_patterns:
            for pat in url_patterns:
                cls._url_patterns.append((pat, source_class))
        if extensions:
            for ext in extensions:
                cls._file_extensions[ext] = source_class

    @classmethod
    def open(cls, name_or_url: str, **kwargs) -> "Stream | Empty":
        """
        Open any data source by name or URL.

        Examples:
            open("SDSS", obj_type="GALAXY")
            open("https://api.gbif.org/v1/occurrence/search")
            open("/data/survey.fits")
            open("kafka://broker:9092/topic")
            open("postgresql://host/db?table=observations")
        """
        # Try named sources first
        if name_or_url in cls._sources:
            return cls._sources[name_or_url](**kwargs).stream()

        # Try URL/path detection
        return cls.from_url(name_or_url, **kwargs)

    @classmethod
    def from_url(cls, url: str, **kwargs) -> "Stream | Empty":
        """Auto-detect source type from URL or file path."""
        url_lower = url.lower()

        # File extensions
        for ext, src_cls in cls._file_extensions.items():
            if url_lower.endswith(ext):
                return src_cls(url, **kwargs).stream()

        # URL schemes
        if url_lower.startswith("kafka://"):
            from .streaming import KafkaSource
            return KafkaSource.from_url(url, **kwargs).stream()
        if url_lower.startswith("mqtt://") or url_lower.startswith("mqtts://"):
            from .streaming import MQTTSource
            return MQTTSource.from_url(url, **kwargs).stream()
        if url_lower.startswith("ws://") or url_lower.startswith("wss://"):
            from .streaming import WebSocketSource
            return WebSocketSource(url, **kwargs).stream()
        if url_lower.startswith("postgresql://") or url_lower.startswith("postgres://"):
            from .database import PostgreSQLSource
            return PostgreSQLSource.from_url(url, **kwargs).stream()
        if url_lower.startswith("mongodb://"):
            from .database import MongoDBSource
            return MongoDBSource.from_url(url, **kwargs).stream()
        if url_lower.startswith("sqlite://") or url_lower.endswith(".db") or url_lower.endswith(".sqlite"):
            from .database import SQLiteSource
            return SQLiteSource.from_url(url, **kwargs).stream()

        # Named URL patterns
        for pat, src_cls in cls._url_patterns:
            if pat in url_lower:
                return src_cls(url, **kwargs).stream()

        # Default: generic REST/JSON
        from .rest import RESTSource
        return RESTSource(url, **kwargs).stream()

    @classmethod
    def list_sources(cls) -> Dict[str, str]:
        return {name: cls._sources[name].description
                for name in cls._sources}


# Global registry instance
REGISTRY = SourceRegistry()
