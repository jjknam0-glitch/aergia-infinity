"""
aergia.connectors
~~~~~~~~~~~~~~~~~
Pre-configured source wrappers for every major updating archive,
organised by scientific domain.

Every connector IS-A lazy ∞T stream. Every one responds to ~>.

Usage:
    from aergia.connectors import astronomy, climate, genomics, finance

    papers    = astronomy.SDSS.galaxies(redshift_min=0.5)
    climate   = climate.ERA5.temperature(lat=51.5, lon=-0.1)
    proteins  = genomics.UniProt.reviewed(organism="human")
    rates     = finance.FRED.series("DFF")   # Fed funds rate

    papers ~> 100
    climate ~> "until 2024-06-01"
    proteins ~> 50
    rates ~> "all"
"""

# Domain namespaces
from . import astronomy
from . import climate
from . import genomics
from . import finance
from . import earth
from . import physics
from . import social

__all__ = ["astronomy", "climate", "genomics", "finance", "earth", "physics", "social"]
