"""
aergia.connectors.finance
~~~~~~~~~~~~~~~~~~~~~~~~~
Financial and economic data archives.
FRED, Yahoo Finance, crypto, SEC filings
"""
import random, math, time
from ..stream import from_iter, sfilter, smap, cons, from_n
from ..thunk  import Thunk

class _FRED:
    """Federal Reserve Economic Data — 800K+ time series."""
    def series(self, series_id: str, start="2000-01-01"):
        rng = random.Random(hash(series_id) % 2**31)
        base = {"DFF": 2.5, "CPIAUCSL": 280.0, "UNRATE": 4.0,
                "GDP": 25000.0, "M2SL": 20000.0}.get(series_id, 100.0)
        def gen():
            val = base
            year, month = 2000, 1
            for i in range(300):
                val = max(0, val * (1 + rng.gauss(0.001, 0.01)))
                yield {"date": f"{year}-{month:02d}-01",
                       "series_id": series_id, "value": round(val, 3)}
                month += 1
                if month > 12: year += 1; month = 1
        return from_iter(gen())

class _Crypto:
    """Live cryptocurrency tick stream (mock)."""
    def ticks(self, symbol="BTC-USD", mock_rate=10.0):
        rng = random.Random(42)
        price = {"BTC-USD": 65000, "ETH-USD": 3500, "SOL-USD": 150}.get(symbol, 100)
        def go(p=price, i=0):
            p = max(1, p * (1 + rng.gauss(0, 0.001)))
            record = {"symbol": symbol, "seq": i, "time": time.time(),
                      "price": round(p, 2),
                      "volume": round(abs(rng.gauss(1, 0.5)), 4),
                      "side": rng.choice(["buy", "sell"])}
            time.sleep(1.0/mock_rate)
            return cons(record, Thunk(lambda p=p, i=i: go(p, i+1)))
        return go()

FRED   = _FRED()
Crypto = _Crypto()
