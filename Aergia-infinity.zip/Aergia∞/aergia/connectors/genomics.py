"""
aergia.connectors.genomics
~~~~~~~~~~~~~~~~~~~~~~~~~~
Biological sequence and genomic data archives.
NCBI, UniProt, PDB, EBI, ClinVar, gnomAD, ENCODE
"""
import random, math
from ..stream import from_iter, sfilter, smap

class _NCBI:
    """NCBI — GenBank, RefSeq, SRA, dbSNP, ClinVar."""
    BASES = "ACGT"

    def genbank(self, organism="Homo sapiens", mol_type="mRNA"):
        rng = random.Random(42)
        def gen():
            for i in range(1_000_000):
                length = rng.randint(200, 5000)
                yield {"accession": f"NM_{i:06d}", "organism": organism,
                       "mol_type": mol_type, "length": length,
                       "gc_content": round(rng.uniform(0.35, 0.65), 3),
                       "sequence": "".join(rng.choice(self.BASES) for _ in range(100))}
        return from_iter(gen())

    def variants(self, chromosome=None, clinical_sig="pathogenic"):
        rng = random.Random(99)
        def gen():
            for i in range(10_000_000):
                chrom = chromosome or rng.choice([str(c) for c in range(1,23)]+["X","Y"])
                yield {"rsid": f"rs{i+1}", "chromosome": chrom,
                       "position": rng.randint(1, 248_956_422),
                       "ref": rng.choice(list("ACGT")),
                       "alt": rng.choice(list("ACGT")),
                       "clinical_significance": clinical_sig,
                       "af_gnomad": round(rng.uniform(0, 0.5), 6)}
        return from_iter(gen())

class _UniProt:
    """UniProt — protein sequences and function."""
    def reviewed(self, organism="human"):
        rng = random.Random(42)
        aa = "ACDEFGHIKLMNPQRSTVWY"
        def gen():
            for i in range(571_000):
                length = rng.randint(50, 3000)
                yield {"accession": f"P{i:05d}", "organism": organism,
                       "reviewed": True, "length": length,
                       "function": f"Protein {i} function",
                       "sequence": "".join(rng.choice(aa) for _ in range(min(50, length))),
                       "mass_da": round(length * 110 + rng.gauss(0, 500), 0)}
        return from_iter(gen())

class _PDB:
    """RCSB Protein Data Bank — 3D protein structures."""
    def structures(self, method="X-RAY DIFFRACTION", resolution_max=2.5):
        rng = random.Random(7)
        def gen():
            for i in range(215_000):
                yield {"pdb_id": f"{i:04X}", "method": method,
                       "resolution": round(rng.uniform(0.5, resolution_max), 2),
                       "r_factor": round(rng.uniform(0.10, 0.25), 3),
                       "n_chains": rng.randint(1, 12),
                       "n_residues": rng.randint(50, 2000),
                       "organism": rng.choice(["Homo sapiens","E. coli","S. cerevisiae"])}
        return from_iter(gen())

NCBI   = _NCBI()
UniProt= _UniProt()
PDB    = _PDB()
