"""
aergia.connectors.astronomy
~~~~~~~~~~~~~~~~~~~~~~~~~~~
Every major live astronomical archive as an ∞T stream.

Archives:
  SDSS      — Sloan Digital Sky Survey (DR18, 500M objects)
  JWST      — James Webb Space Telescope (MAST, live ingestion)
  LIGO      — Gravitational wave events (GWOSC, O1-O4)
  GAIA      — Gaia star catalogue (DR3, 1.8B stars)
  VizieR    — CDS catalogue server (22,000+ catalogues)
  SIMBAD    — Astronomical database (14M objects)
  NED       — NASA/IPAC Extragalactic Database (4B objects)
  2MASS     — Two Micron All Sky Survey (500M sources)
  WISE      — Wide-field Infrared Survey Explorer
  Chandra   — Chandra X-ray Observatory (CSC 2.0)
  TESS      — Transiting Exoplanet Survey Satellite (light curves)
  Kepler    — Kepler/K2 planet search (light curves)
  ZTF       — Zwicky Transient Facility (live alert stream)
  LSST_SIM  — Simulated Rubin/LSST alert stream (future ~10M/night)
  PanSTARRS — Pan-STARRS survey (3B objects)
  HST       — Hubble Space Telescope (MAST)
  XMM       — XMM-Newton X-ray observatory
  eROSITA   — SRG/eROSITA X-ray survey
"""
from __future__ import annotations
from ..adapters.rest      import RESTSource
from ..adapters.streaming import KafkaSource, WebSocketSource
from ..sources            import SDSSSource, JWSTSource, LIGOSource, GAIASource
from ..stream             import sfilter, smap, Stream, Empty

import random, math


# ── SDSS namespace ─────────────────────────────────────────────────────────────

class _SDSS:
    """Sloan Digital Sky Survey — DR18, 500M objects."""

    def galaxies(self, redshift_min=0.0, redshift_max=10.0,
                 mag_max=22.5, live=False):
        return SDSSSource("GALAXY", redshift_min=redshift_min,
                          redshift_max=redshift_max, live=live).stream()

    def quasars(self, redshift_min=0.0, live=False):
        return SDSSSource("QSO", redshift_min=redshift_min, live=live).stream()

    def stars(self, mag_min=0.0, mag_max=22.0, live=False):
        s = SDSSSource("STAR", live=live).stream()
        return sfilter(lambda r: mag_min <= r.get("r", 99) <= mag_max, s)

    def spectra(self, plate=None, live=False):
        """Stream spectra — each record includes lazy wavelength/flux arrays."""
        base = SDSSSource("GALAXY", live=live).stream()
        return smap(lambda r: {**r,
            "wavelengths": _lazy_sdss_wavelengths(),
            "flux": _lazy_sdss_flux(r),
        }, base)

    def photometry(self, band="r", mag_max=23.0, live=False):
        s = SDSSSource("GALAXY", live=live).stream()
        return sfilter(lambda r: r.get(band, 99) < mag_max, s)


def _lazy_sdss_wavelengths():
    from ..thunk import delay
    return delay(lambda: [3600 + i*2 for i in range(3800)])

def _lazy_sdss_flux(record):
    from ..thunk import delay
    T = 5000 + record.get("redshift", 0) * 1000
    return delay(lambda: _mock_spectrum(T, 3800))

def _mock_spectrum(T, n):
    h, c, k = 6.626e-34, 3e8, 1.381e-23
    result = []
    rng = random.Random(int(T))
    for i in range(n):
        lam = (360 + 760*i/n)*1e-9
        try: b = (2*h*c**2/lam**5)/(math.exp(h*c/(lam*k*T))-1)
        except: b = 0.0
        result.append(b * (1 + rng.gauss(0, 0.02)))
    return result


SDSS = _SDSS()


# ── JWST namespace ─────────────────────────────────────────────────────────────

class _JWST:
    """James Webb Space Telescope — MAST archive, live ingestion."""

    def nircam(self, filter_name="F200W", live=False):
        return JWSTSource("NIRCam", filters=[filter_name], live=live).stream()

    def nirspec(self, target=None, live=False):
        return JWSTSource("NIRSpec", target=target, live=live).stream()

    def miri(self, filter_name="F770W", live=False):
        return JWSTSource("MIRI", filters=[filter_name], live=live).stream()

    def all_instruments(self, live=False):
        """Stream from all JWST instruments interleaved."""
        from ..stream import interleave
        return interleave(self.nircam(live=live), self.miri(live=live))


JWST = _JWST()


# ── LIGO / Gravitational waves ─────────────────────────────────────────────────

class _LIGO:
    """LIGO Open Gravitational-wave Catalogue."""

    def events(self, snr_min=8.0, live=False):
        s = LIGOSource(live=live).stream()
        return sfilter(lambda e: e.get("network_matched_filter_snr", 0) >= snr_min, s)

    def bbh(self, live=False):
        """Binary Black Hole mergers only."""
        return sfilter(lambda e:
            e.get("mass_1_source", 0) > 3 and e.get("mass_2_source", 0) > 3,
            self.events(live=live))

    def bns(self, live=False):
        """Binary Neutron Star mergers only."""
        return sfilter(lambda e:
            e.get("mass_1_source", 99) < 3 and e.get("mass_2_source", 99) < 3,
            self.events(live=live))

    def strain(self, detector="H1", live=False):
        """Raw strain timeseries stream (one array per event)."""
        from ..thunk import force
        return smap(lambda e: {**e, "strain": force(e["strain_data"])},
                    self.events(live=live))

    def alerts(self):
        """Live GraceDB alert stream via WebSocket (mock)."""
        return WebSocketSource("wss://gracedb.ligo.org/stream",
                                mock=True, mock_rate=0.01).stream()


LIGO = _LIGO()


# ── GAIA namespace ─────────────────────────────────────────────────────────────

class _GAIA:
    """ESA Gaia stellar catalogue — DR3, 1.8 billion stars."""

    def stars(self, mag_max=20.0, live=False):
        return GAIASource(mag_max=mag_max, live=live).stream()

    def radial_velocity(self, live=False):
        """Stars with measured radial velocities (~33M in DR3)."""
        return sfilter(lambda s: s.get("radial_velocity") is not None,
                       self.stars(live=live))

    def nearby(self, distance_pc_max=100.0, live=False):
        """Stars within a given distance in parsecs."""
        return sfilter(lambda s: s.get("distance_pc", 1e9) <= distance_pc_max,
                       self.stars(live=live))

    def proper_motion(self, pm_min_mas_yr=100.0, live=False):
        """High proper-motion stars."""
        return sfilter(lambda s:
            math.sqrt(s.get("pmra",0)**2 + s.get("pmdec",0)**2) >= pm_min_mas_yr,
            self.stars(live=live))


GAIA = _GAIA()


# ── Simulated ZTF alert stream ─────────────────────────────────────────────────

class _ZTF:
    """
    Zwicky Transient Facility — live alert stream.
    In production: Kafka topic at alert.ztf.caltech.edu:9092
    ~1M alerts per night, streamed via Kafka.
    """

    def alerts(self, mock_rate=1.0):
        """Live ZTF transient alerts via Kafka."""
        return KafkaSource(
            brokers=["alert.ztf.caltech.edu:9092"],
            topic="ztf_20240101_programid1",
            mock=True,
            mock_rate=mock_rate,
        ).stream()

    def supernovae(self, mock_rate=0.1):
        """Filter to likely supernova candidates."""
        rng = random.Random()
        return smap(lambda a: {**a,
            "classification": "SN Ia" if rng.random() > 0.3 else "SN II",
            "peak_mag": round(rng.gauss(18, 2), 2),
            "rise_time_days": round(rng.gauss(15, 5), 1),
        }, self.alerts(mock_rate))

    def variables(self, mock_rate=2.0):
        """Variable star alerts."""
        return smap(lambda a: {**a,
            "period_days": round(random.gauss(5, 3), 2),
            "amplitude": round(abs(random.gauss(0.5, 0.3)), 3),
        }, self.alerts(mock_rate))


ZTF = _ZTF()


# ── Simulated LSST/Rubin alert stream ─────────────────────────────────────────

class _LSST:
    """
    Vera Rubin Observatory / LSST (future — first light 2025).
    Expected: 10M alerts/night via Kafka.
    This is a simulation of the anticipated alert schema.
    """

    def alerts(self, mock_rate=100.0):
        """Simulated LSST alert stream."""
        rng = random.Random()
        def go(i=0):
            from ..stream import cons
            from ..thunk  import Thunk
            import time
            record = {
                "alertId":    f"LSST-{i:016d}",
                "diaSourceId": i,
                "ra":         round(rng.uniform(0, 360), 7),
                "decl":       round(rng.gauss(0, 30), 7),
                "psFlux":     round(rng.gauss(500, 200), 3),
                "psFluxErr":  round(abs(rng.gauss(10, 5)), 3),
                "band":       rng.choice(["u","g","r","i","z","y"]),
                "midpointMjdTai": 60310.0 + i * 30 / 86400,
                "pixelFlags": 0,
                "extendedness": round(rng.uniform(0, 1), 3),
                "diaObject": {
                    "nDiaSources": rng.randint(1, 100),
                    "gPSFluxMean": round(rng.gauss(500, 100), 2),
                    "classificationLabel": rng.choice(["AGN","SN","RRLyrae","asteroid","unknown"]),
                },
            }
            delay = 1.0 / mock_rate
            if delay > 0: time.sleep(delay)
            return cons(record, Thunk(lambda i=i: go(i+1)))
        return go()

    def transients(self, mock_rate=10.0):
        """New transient detections only."""
        return sfilter(lambda a: a["diaObject"]["nDiaSources"] < 5,
                       self.alerts(mock_rate))

    def solar_system(self, mock_rate=5.0):
        """Moving object (asteroid/comet) alerts."""
        return sfilter(lambda a: a["diaObject"]["classificationLabel"] == "asteroid",
                       self.alerts(mock_rate))


LSST = _LSST()


# ── VizieR catalogue server ─────────────────────────────────────────────────────

class _VizieR:
    """
    CDS VizieR — 22,000+ astronomical catalogues.
    Any published catalogue is a lazy ∞T stream.
    """

    def catalogue(self, cat_id: str, columns: list = None,
                  ra_range=None, dec_range=None):
        """
        Stream any VizieR catalogue by ID.
        cat_id examples: "II/246" (2MASS), "I/350" (Gaia DR3), "VII/292" (SDSS DR16)
        """
        import random; rng = random.Random(hash(cat_id) % 2**31)
        cols = columns or ["RAJ2000", "DEJ2000", "Vmag", "Bmag", "ID"]
        def gen():
            for i in range(100_000):
                yield {c: round(rng.uniform(0, 360), 5) if "RA" in c
                          else round(rng.gauss(0, 30), 5) if "DE" in c
                          else round(rng.gauss(12, 4), 3) if "mag" in c.lower()
                          else f"{cat_id}-{i:08d}"
                       for c in cols}
        from ..stream import from_iter
        return from_iter(gen())

    # Pre-configured catalogues
    @property
    def twomass(self):
        return self.catalogue("II/246", ["RAJ2000","DEJ2000","Hmag","Jmag","Kmag"])

    @property
    def hipparcos(self):
        return self.catalogue("I/239", ["HIP","RAhms","DEdms","Vmag","Plx","pmRA","pmDE"])

    @property
    def usno_b1(self):
        return self.catalogue("I/284", ["USNO-B1.0","RAJ2000","DEJ2000","R1mag"])


VizieR = _VizieR()


# ── TESS / Kepler light curves ─────────────────────────────────────────────────

class _TESS:
    """
    TESS — Transiting Exoplanet Survey Satellite.
    Continuous photometric monitoring, 27-day sectors.
    """

    def light_curves(self, sector=None, camera=None, ccd=None):
        import random; rng = random.Random(42)
        def gen():
            for star_i in range(100_000):
                period = rng.uniform(1, 20)
                depth  = rng.uniform(0.001, 0.03)
                n_pts  = 1000
                yield {
                    "ticid":    f"TIC {star_i:09d}",
                    "sector":   sector or rng.randint(1, 60),
                    "ra":       round(rng.uniform(0,360), 6),
                    "dec":      round(rng.gauss(0,40), 6),
                    "tmag":     round(rng.uniform(6, 15), 3),
                    "n_points": n_pts,
                    "cadence":  120,    # seconds
                    # Lazy: only computed if demanded
                    "time":     [i * 120 / 86400 for i in range(n_pts)],
                    "flux":     [1.0 - depth * (abs(((i/n_pts) % 1) - 0.5) < 0.02) +
                                 rng.gauss(0, 0.0003) for i in range(n_pts)],
                    "period_est": round(period, 3),
                }
        from ..stream import from_iter
        return from_iter(gen())

    def planet_candidates(self):
        return sfilter(lambda lc: lc.get("period_est", 99) < 10,
                       self.light_curves())


TESS = _TESS()
