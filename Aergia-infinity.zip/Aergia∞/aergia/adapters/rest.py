"""
aergia.adapters.rest
~~~~~~~~~~~~~~~~~~~~
Universal REST/HTTP adapter.

Handles any JSON API automatically by detecting pagination patterns:
  - Offset/limit:   ?offset=0&limit=100
  - Page/per_page:  ?page=1&per_page=100
  - Cursor:         ?cursor=abc123
  - Link header:    next/prev/last in HTTP Link header
  - next_url:       JSON field containing next page URL

Supports:
  - JSON arrays
  - JSON objects with a records/results/items/data field
  - Newline-delimited JSON (NDJSON)
  - JSON-Lines
  - Auto-detected authentication (Bearer, API key header, query param)

Usage in Æergia∞:
  source papers : ∞Paper = REST "https://api.openalex.org/works"
    params  = { filter = "publication_year:2024" }
    records = "results"
    next    = "meta.next_cursor"

Python equivalent:
  from aergia.adapters.rest import RESTSource
  papers = RESTSource("https://api.openalex.org/works",
                      params={"filter": "publication_year:2024"},
                      records_key="results",
                      next_key="meta.next_cursor")
"""
from __future__ import annotations
import time
import json
from typing import Any, Dict, List, Optional, Callable

from .protocol import SourceProtocol, REGISTRY
from ..stream  import Stream, Empty, EMPTY, cons, from_iter
from ..thunk   import Thunk


class RESTSource(SourceProtocol):
    """
    Universal paginated REST/JSON source.

    Auto-detects pagination scheme from the first response.
    Supports offset, cursor, page-number, and Link-header pagination.
    """
    name        = "REST"
    description = "Generic paginated JSON REST API"
    update_freq = "varies"

    # Auto-detected record container keys (tried in order)
    _AUTO_RECORD_KEYS = [
        "results", "records", "items", "data", "features",
        "hits", "docs", "objects", "entities", "rows",
        "events", "entries", "values", "content", "list",
        "resources", "members", "elements", "payload",
    ]

    # Auto-detected next-cursor keys
    _AUTO_NEXT_KEYS = [
        "next", "next_cursor", "nextCursor", "next_page",
        "nextPage", "cursor", "continuation", "next_token",
        "nextToken", "after", "bookmark",
    ]

    def __init__(
        self,
        url:          str,
        params:       Dict[str, Any]  = None,
        headers:      Dict[str, str]  = None,
        records_key:  Optional[str]   = None,    # auto-detected if None
        next_key:     Optional[str]   = None,    # auto-detected if None
        page_size:    int             = 200,
        page_param:   str             = "limit",
        offset_param: str             = "offset",
        page_num_param: Optional[str] = None,    # e.g. "page"
        auth_header:  Optional[str]   = None,    # "Bearer TOKEN"
        auth_param:   Optional[str]   = None,    # ("api_key", "TOKEN")
        rate_limit_rps: float         = 10.0,    # requests per second
        retry_times:  int             = 3,
        transform:    Optional[Callable] = None, # record post-processor
        mock:         bool            = False,   # use mock data
        mock_total:   int             = 1000,
    ) -> None:
        self.url           = url
        self.params        = params or {}
        self.headers       = headers or {}
        self.records_key   = records_key
        self.next_key      = next_key
        self.page_size     = page_size
        self.page_param    = page_param
        self.offset_param  = offset_param
        self.page_num_param= page_num_param
        self.auth_header   = auth_header
        self.auth_param    = auth_param
        self.rate_limit_rps= rate_limit_rps
        self.retry_times   = retry_times
        self.transform     = transform
        self.mock          = mock
        self.mock_total    = mock_total
        self._last_req     = 0.0
        self._detected_scheme: Optional[str] = None

    def _rate_limit(self) -> None:
        if self.rate_limit_rps <= 0:
            return
        min_gap = 1.0 / self.rate_limit_rps
        elapsed = time.time() - self._last_req
        if elapsed < min_gap:
            time.sleep(min_gap - elapsed)
        self._last_req = time.time()

    def _build_headers(self) -> Dict[str, str]:
        h = {"Accept": "application/json", **self.headers}
        if self.auth_header:
            h["Authorization"] = self.auth_header
        return h

    def _build_params(self, extra: Dict = None) -> Dict:
        p = {**self.params, self.page_param: self.page_size}
        if self.auth_param:
            key, val = self.auth_param
            p[key] = val
        if extra:
            p.update(extra)
        return p

    def _fetch_page(self, offset: int = 0, cursor: str = None,
                    page_num: int = None, next_url: str = None) -> Dict:
        """Fetch one page. Returns {"records": [...], "next": cursor_or_offset_or_None}."""
        if self.mock:
            return self._mock_page(offset)

        import urllib.request, urllib.parse, urllib.error

        # Build URL
        url = next_url or self.url
        extra = {}
        if cursor:
            extra[self.next_key or "cursor"] = cursor
        elif page_num is not None and self.page_num_param:
            extra[self.page_num_param] = page_num
        elif not next_url:
            extra[self.offset_param] = offset

        params = self._build_params(extra)
        full_url = url + "?" + urllib.parse.urlencode(params) if "?" not in url else \
                   url + "&" + urllib.parse.urlencode(params)

        for attempt in range(self.retry_times):
            try:
                self._rate_limit()
                req = urllib.request.Request(full_url, headers=self._build_headers())
                with urllib.request.urlopen(req, timeout=30) as resp:
                    body = resp.read().decode("utf-8")
                    link_header = resp.headers.get("Link", "")
                    return self._parse_response(body, link_header, offset)
            except urllib.error.HTTPError as e:
                if e.code == 429:   # rate limited
                    time.sleep(2 ** attempt)
                    continue
                if attempt == self.retry_times - 1:
                    return {"records": [], "next": None}
            except Exception:
                if attempt == self.retry_times - 1:
                    return {"records": [], "next": None}
                time.sleep(1)

        return {"records": [], "next": None}

    def _parse_response(self, body: str, link_header: str, offset: int) -> Dict:
        """Parse JSON response and extract records + next pointer."""
        # Handle NDJSON (one JSON object per line)
        if body.strip().startswith("{") and "\n{" in body:
            records = [json.loads(line) for line in body.strip().split("\n")
                       if line.strip()]
            return {"records": records, "next": offset + len(records) if records else None}

        try:
            data = json.loads(body)
        except json.JSONDecodeError:
            return {"records": [], "next": None}

        # Extract records
        records = self._extract_records(data)
        if not records:
            return {"records": [], "next": None}

        # Extract next pointer
        next_ptr = self._extract_next(data, link_header, offset, len(records))
        if self.transform:
            records = [self.transform(r) for r in records]

        return {"records": records, "next": next_ptr}

    def _extract_records(self, data: Any) -> List[Dict]:
        """Find the list of records in the response."""
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            # Try auto-detected key first
            if self.records_key and self.records_key in data:
                val = data[self.records_key]
                return val if isinstance(val, list) else []
            # Auto-detect
            for key in self._AUTO_RECORD_KEYS:
                if key in data and isinstance(data[key], list):
                    self.records_key = key   # cache for next time
                    return data[key]
            # Nested keys (e.g. "meta.results")
            for key in self._AUTO_RECORD_KEYS:
                for top_key, top_val in data.items():
                    if isinstance(top_val, dict) and key in top_val:
                        if isinstance(top_val[key], list):
                            return top_val[key]
        return []

    def _extract_next(self, data: Any, link_header: str,
                      offset: int, n_records: int) -> Any:
        """Determine the next page pointer."""
        if isinstance(data, dict):
            # Cursor-based
            for key in self._AUTO_NEXT_KEYS:
                if key in data and data[key]:
                    return {"cursor": data[key]}
                # Nested: meta.next_cursor etc.
                for top_val in data.values():
                    if isinstance(top_val, dict) and key in top_val and top_val[key]:
                        return {"cursor": top_val[key]}

            # Total count → offset-based
            for count_key in ["total", "count", "total_count", "totalCount", "total_results", "numFound"]:
                if count_key in data:
                    total = data[count_key]
                    if isinstance(total, (int, float)) and offset + n_records < total:
                        return {"offset": offset + n_records}
                for top_val in data.values():
                    if isinstance(top_val, dict) and count_key in top_val:
                        total = top_val[count_key]
                        if isinstance(total, (int, float)) and offset + n_records < total:
                            return {"offset": offset + n_records}

        # Link header: rel="next"
        if 'rel="next"' in link_header:
            for part in link_header.split(","):
                if 'rel="next"' in part:
                    url = part.split(";")[0].strip().strip("<>")
                    return {"next_url": url}

        # Default: try offset if we got a full page
        if n_records == self.page_size:
            return {"offset": offset + n_records}

        return None

    def _mock_page(self, offset: int) -> Dict:
        """Deterministic mock data for testing without network."""
        import random
        rng = random.Random(offset * 7919)
        if offset >= self.mock_total:
            return {"records": [], "next": None}
        batch = min(self.page_size, self.mock_total - offset)
        records = [{"id": offset + i, "value": rng.random(),
                    "label": f"record-{offset+i}"} for i in range(batch)]
        nxt = {"offset": offset + batch} if offset + batch < self.mock_total else None
        return {"records": records, "next": nxt}

    def stream(self) -> "Stream | Empty":
        """Return the infinite lazy stream over this REST source."""
        def go(state: Dict) -> "Stream | Empty":
            resp = self._fetch_page(**state)
            records = resp["records"]
            next_ptr = resp["next"]
            if not records:
                return EMPTY
            def build(i: int) -> "Stream | Empty":
                if i >= len(records):
                    if next_ptr is None:
                        return EMPTY
                    return go(next_ptr)
                return cons(records[i], Thunk(lambda i=i: build(i + 1)))
            return build(0)
        return go({"offset": 0})

    def checkpoint(self) -> Optional[str]:
        return json.dumps({"offset": 0, "url": self.url})


# ── Pre-configured connectors for major REST APIs ─────────────────────────────

class OpenAlexSource(RESTSource):
    """
    OpenAlex — open scholarly works database.
    200M+ papers, updated daily.
    No API key needed for basic use.
    """
    name        = "OpenAlex"
    description = "200M+ scholarly works (papers, authors, institutions)"
    update_freq = "daily"

    def __init__(self, entity: str = "works", filter_str: str = "",
                 sort: str = "cited_by_count:desc", **kwargs):
        super().__init__(
            url         = f"https://api.openalex.org/{entity}",
            params      = {k: v for k, v in {
                "filter": filter_str, "sort": sort,
                "select": "id,title,doi,publication_year,cited_by_count,"
                          "authorships,primary_location,open_access"
            }.items() if v},
            records_key = "results",
            next_key    = "next_cursor",
            page_size   = 200,
            page_param  = "per-page",
            offset_param= "cursor",
            **kwargs,
        )
        self.name = f"OpenAlex({entity})"


class GBIFSource(RESTSource):
    """
    GBIF — Global Biodiversity Information Facility.
    2+ billion species occurrence records, continuously updated.
    """
    name        = "GBIF"
    description = "2B+ species occurrence records worldwide"
    update_freq = "realtime"

    def __init__(self, taxon_key: int = None, country: str = None,
                 year: str = None, **kwargs):
        params = {"limit": 300}
        if taxon_key: params["taxonKey"] = taxon_key
        if country:   params["country"]  = country
        if year:      params["year"]     = year
        super().__init__(
            url         = "https://api.gbif.org/v1/occurrence/search",
            params      = params,
            records_key = "results",
            page_size   = 300,
            page_param  = "limit",
            offset_param= "offset",
            **kwargs,
        )


class NOAAClimateSource(RESTSource):
    """
    NOAA Climate Data Online API.
    Requires free API token: https://www.ncdc.noaa.gov/cdo-web/token
    """
    name        = "NOAA"
    description = "NOAA Climate Data Online — weather station records"
    update_freq = "daily"

    def __init__(self, dataset_id: str = "GHCND", api_token: str = "",
                 station_id: str = None, start_date: str = "2020-01-01",
                 end_date: str = "2024-01-01", **kwargs):
        params = {
            "datasetid": dataset_id,
            "startdate": start_date,
            "enddate":   end_date,
        }
        if station_id: params["stationid"] = station_id
        super().__init__(
            url         = "https://www.ncdc.noaa.gov/cdo-web/api/v2/data",
            params      = params,
            headers     = {"token": api_token} if api_token else {},
            records_key = "results",
            page_size   = 1000,
            **kwargs,
        )


class ArXivSource(RESTSource):
    """
    arXiv preprint server.
    2M+ papers, updated daily.
    """
    name        = "arXiv"
    description = "arXiv preprints (physics, math, CS, bio, econ, ...)"
    update_freq = "daily"

    def __init__(self, category: str = "astro-ph", max_results: int = 100, **kwargs):
        import urllib.parse
        super().__init__(
            url    = "http://export.arxiv.org/api/query",
            params = {
                "search_query": f"cat:{category}",
                "sortBy":       "lastUpdatedDate",
                "sortOrder":    "descending",
                "max_results":  min(max_results, 2000),
            },
            page_size = min(max_results, 200),
            **kwargs,
        )
        self._category = category

    def stream(self) -> "Stream | Empty":
        """arXiv returns Atom XML, so we parse that."""
        import urllib.request, xml.etree.ElementTree as ET
        try:
            params = f"search_query=cat:{self._category}&sortBy=lastUpdatedDate&max_results={self.page_size}"
            url = f"http://export.arxiv.org/api/query?{params}"
            with urllib.request.urlopen(url, timeout=30) as r:
                xml_body = r.read().decode("utf-8")
            ns = {"atom": "http://www.w3.org/2005/Atom"}
            root = ET.fromstring(xml_body)
            records = []
            for entry in root.findall("atom:entry", ns):
                records.append({
                    "id":       (entry.findtext("atom:id", "", ns) or "").split("/")[-1],
                    "title":    (entry.findtext("atom:title", "", ns) or "").strip(),
                    "summary":  (entry.findtext("atom:summary", "", ns) or "").strip()[:300],
                    "published":entry.findtext("atom:published", "", ns),
                    "authors":  [a.findtext("atom:name", "", ns) for a in entry.findall("atom:author", ns)],
                    "category": self._category,
                    "pdf_url":  next((l.get("href","") for l in entry.findall("atom:link",ns)
                                      if l.get("type","") == "application/pdf"), ""),
                })
            return from_iter(iter(records))
        except Exception:
            return from_iter(iter([]))


class WikidataSPARQLSource(SourceProtocol):
    """
    Wikidata SPARQL endpoint.
    90M+ entities, updated continuously.
    """
    name        = "Wikidata"
    description = "Wikidata knowledge graph — 90M+ entities"
    update_freq = "realtime"

    ENDPOINT = "https://query.wikidata.org/sparql"

    def __init__(self, sparql_query: str, page_size: int = 1000, **kwargs):
        self.sparql_query = sparql_query
        self.page_size    = page_size

    def stream(self) -> "Stream | Empty":
        import urllib.request, urllib.parse, json as _json
        offset = 0
        def go(offset: int) -> "Stream | Empty":
            query = f"{self.sparql_query}\nLIMIT {self.page_size} OFFSET {offset}"
            try:
                encoded = urllib.parse.urlencode({"query": query, "format": "json"})
                url = f"{self.ENDPOINT}?{encoded}"
                req = urllib.request.Request(url, headers={
                    "Accept": "application/sparql-results+json",
                    "User-Agent": "AergiaInfinity/0.1",
                })
                with urllib.request.urlopen(req, timeout=30) as r:
                    data = _json.loads(r.read().decode())
                rows = data.get("results", {}).get("bindings", [])
                if not rows:
                    return EMPTY
                records = [{k: v.get("value") for k, v in row.items()} for row in rows]
                def build(i: int) -> "Stream | Empty":
                    if i >= len(records):
                        return go(offset + len(records)) if len(records) == self.page_size else EMPTY
                    return cons(records[i], Thunk(lambda i=i: build(i+1)))
                return build(0)
            except Exception:
                return EMPTY
        return go(0)


class FREDSource(RESTSource):
    """
    Federal Reserve Economic Data (FRED).
    800,000+ economic time series.
    Free API key: https://fred.stlouisfed.org/docs/api/api_key.html
    """
    name        = "FRED"
    description = "800K+ US economic time series (Fed, BLS, BEA, ...)"
    update_freq = "varies"

    def __init__(self, series_id: str, api_key: str = "", **kwargs):
        super().__init__(
            url    = "https://api.stlouisfed.org/fred/series/observations",
            params = {"series_id": series_id, "file_type": "json",
                      "api_key": api_key or ""},
            records_key  = "observations",
            page_size    = 1000,
            page_param   = "limit",
            offset_param = "offset",
            **kwargs,
        )
        self.name = f"FRED({series_id})"


class OpenMeteoSource(RESTSource):
    """
    Open-Meteo — free weather API with historical + forecast data.
    No API key needed.
    """
    name        = "OpenMeteo"
    description = "Free weather data: historical + 16-day forecast"
    update_freq = "hourly"

    def __init__(self, latitude: float, longitude: float,
                 variables: list = None, **kwargs):
        vars_ = ",".join(variables or ["temperature_2m","precipitation","wind_speed_10m"])
        super().__init__(
            url    = "https://api.open-meteo.com/v1/forecast",
            params = {
                "latitude":  latitude,
                "longitude": longitude,
                "hourly":    vars_,
                "timezone":  "UTC",
            },
            mock = True,  # structure demo
            **kwargs,
        )
        self._lat = latitude
        self._lon = longitude
        self._vars = vars_

    def stream(self) -> "Stream | Empty":
        """Open-Meteo returns a different structure — all hours at once."""
        import urllib.request, urllib.parse, json as _json, math
        try:
            params = urllib.parse.urlencode({
                "latitude": self._lat, "longitude": self._lon,
                "hourly": self._vars, "timezone": "UTC",
                "forecast_days": 16,
            })
            url = f"https://api.open-meteo.com/v1/forecast?{params}"
            with urllib.request.urlopen(url, timeout=30) as r:
                data = _json.loads(r.read().decode())
            hourly = data.get("hourly", {})
            times  = hourly.get("time", [])
            vars_list = [k for k in hourly if k != "time"]
            records = [
                {"time": t, **{v: hourly[v][i] for v in vars_list}}
                for i, t in enumerate(times)
            ]
            return from_iter(iter(records))
        except Exception as e:
            # Return mock weather for demo
            import random
            rng = random.Random(int(self._lat * 100 + self._lon * 100))
            records = [
                {"time": f"2024-01-{i//24+1:02d}T{i%24:02d}:00",
                 "temperature_2m": round(15 + 10*math.sin(i*6.283/24) + rng.gauss(0,2), 1),
                 "precipitation":  max(0, round(rng.gauss(0.5, 2), 1)),
                 "wind_speed_10m": round(abs(rng.gauss(15, 8)), 1)}
                for i in range(384)   # 16 days × 24 hours
            ]
            return from_iter(iter(records))


class GitHubSource(RESTSource):
    """
    GitHub REST API — repositories, commits, issues, stars.
    60 req/hour unauthenticated, 5000/hour with token.
    """
    name        = "GitHub"
    description = "GitHub repositories, commits, issues, PRs"
    update_freq = "realtime"

    def __init__(self, endpoint: str, token: str = "", **kwargs):
        super().__init__(
            url         = f"https://api.github.com/{endpoint.lstrip('/')}",
            headers     = {"Authorization": f"token {token}"} if token else {},
            page_size   = 100,
            page_param  = "per_page",
            offset_param= "page",
            **kwargs,
        )
        self.name = f"GitHub({endpoint})"


class OpenFDASource(RESTSource):
    """
    FDA Open Data — drug adverse events, recalls, labeling.
    No API key needed.
    """
    name        = "OpenFDA"
    description = "FDA drug adverse events, recalls, and labeling"
    update_freq = "weekly"

    def __init__(self, endpoint: str = "drug/event", search: str = "",
                 **kwargs):
        super().__init__(
            url         = f"https://api.fda.gov/{endpoint}.json",
            params      = {"search": search} if search else {},
            records_key = "results",
            page_size   = 100,
            page_param  = "limit",
            offset_param= "skip",
            **kwargs,
        )


# ── Register all REST sources ───────────────────────────────────────────────

REGISTRY.register("OpenAlex", OpenAlexSource,
    url_patterns=["openalex.org"])
REGISTRY.register("GBIF", GBIFSource,
    url_patterns=["api.gbif.org"])
REGISTRY.register("NOAA", NOAAClimateSource,
    url_patterns=["ncdc.noaa.gov"])
REGISTRY.register("arXiv", ArXivSource,
    url_patterns=["arxiv.org"])
REGISTRY.register("Wikidata", WikidataSPARQLSource,
    url_patterns=["wikidata.org", "query.wikidata.org"])
REGISTRY.register("FRED", FREDSource,
    url_patterns=["fred.stlouisfed.org", "api.stlouisfed.org"])
REGISTRY.register("OpenMeteo", OpenMeteoSource,
    url_patterns=["open-meteo.com"])
REGISTRY.register("GitHub", GitHubSource,
    url_patterns=["api.github.com"])
REGISTRY.register("OpenFDA", OpenFDASource,
    url_patterns=["api.fda.gov"])
