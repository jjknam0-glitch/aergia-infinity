"""
aergia.adapters
~~~~~~~~~~~~~~~
Universal data source adapter layer.

Single entry point: open() returns a lazy ∞T stream from ANY source.

    from aergia.adapters import open_any

    # REST APIs
    papers   = open_any("OpenAlex", filter_str="publication_year:2024")
    species  = open_any("GBIF", taxon_key=212)
    weather  = open_any("OpenMeteo", latitude=51.5, longitude=-0.1)
    arxiv    = open_any("arXiv", category="cs.LG")

    # Live streams
    sensors  = open_any("MQTT", broker="broker.hivemq.com", topic="sensors/#")
    events   = open_any("Kafka", brokers="localhost:9092", topic="my-topic")

    # Files
    survey   = open_any("/data/gaia_dr3.fits")          # FITS
    climate  = open_any("/data/era5_2023.nc")           # NetCDF
    genome   = open_any("/data/GRCh38.fa.gz")           # FASTA
    big_data = open_any("/data/survey.parquet")         # Parquet

    # Databases
    table    = open_any("postgresql://host/db?table=obs")
    docs     = open_any("mongodb://host/db", collection="events", live=True)
    local    = open_any("observations.db", table="readings")

    # URL auto-detection
    any_api  = open_any("https://api.example.com/data")

    # All return the same type: ∞T
    # Use ~> to demand records:
    result   = open_any("OpenAlex") ~> 100
"""
from .protocol  import SourceProtocol, SourceRegistry, REGISTRY
from .rest      import (RESTSource, OpenAlexSource, GBIFSource, NOAAClimateSource,
                         ArXivSource, WikidataSPARQLSource, FREDSource,
                         OpenMeteoSource, GitHubSource, OpenFDASource)
from .streaming import WebSocketSource, KafkaSource, MQTTSource, SSESource
from .files     import (FITSSource, HDF5Source, ParquetSource, NetCDFSource,
                         FASTASource, CSVStreamSource, NDJSONSource)
from .database  import (PostgreSQLSource, MongoDBSource, SQLiteSource,
                         DuckDBSource, InfluxDBSource)


def open_any(name_or_path: str, **kwargs):
    """
    Universal source opener. Returns a lazy ∞T stream.

    Works with:
      - Named sources:   open_any("SDSS"), open_any("GBIF")
      - File paths:      open_any("/data/survey.fits")
      - URLs:            open_any("https://api.example.com/data")
      - DB URLs:         open_any("postgresql://host/db")
      - Stream URLs:     open_any("kafka://broker/topic")
    """
    return REGISTRY.open(name_or_path, **kwargs)


def list_sources() -> dict:
    """List all registered data sources."""
    from ..sources import REGISTRY as OLD_REGISTRY
    sources = {}
    sources.update({
        "FITS":         "Astronomical data files (Hubble, JWST, Chandra, VLT)",
        "HDF5":         "Scientific hierarchical data (neuroscience, physics)",
        "Parquet":      "Big data columnar format (Spark, BigQuery, dbt)",
        "NetCDF":       "Climate and oceanography grids (ERA5, CMIP6, GFS)",
        "FASTA":        "Genomic sequences (human genome, metagenomics)",
        "CSV":          "Delimited text files (any)",
        "NDJSON":       "Newline-delimited JSON",
        "OpenAlex":     "200M+ scholarly papers (open access)",
        "GBIF":         "2B+ biodiversity observations worldwide",
        "NOAA":         "US climate and weather station records",
        "arXiv":        "Preprints: physics, math, CS, bio, econ",
        "Wikidata":     "90M+ entities via SPARQL",
        "FRED":         "800K+ economic time series (Federal Reserve)",
        "OpenMeteo":    "Free weather: history + 16-day forecast",
        "GitHub":       "Repositories, commits, issues, PRs",
        "OpenFDA":      "FDA drug adverse events and recalls",
        "WebSocket":    "Live WebSocket JSON stream (any)",
        "Kafka":        "Distributed event stream (LSST, SKA, IoT)",
        "MQTT":         "IoT sensor streams (weather, telemetry)",
        "SSE":          "Server-Sent Events (GitHub events, live APIs)",
        "PostgreSQL":   "SQL table + live LISTEN/NOTIFY change streaming",
        "MongoDB":      "Document collection + live Change Streams",
        "SQLite":       "Local embedded database (no server needed)",
        "DuckDB":       "Analytical SQL over Parquet/CSV/JSON files",
        "InfluxDB":     "IoT and metrics time-series database",
        # Original astronomical sources
        "SDSS":         "Sloan Digital Sky Survey (spectra, photometry)",
        "JWST":         "James Webb Space Telescope (MAST archive)",
        "LIGO":         "Gravitational wave open data (GWOSC)",
        "GAIA":         "Gaia stellar catalogue DR3 (1.8B stars)",
    })
    return sources


__all__ = [
    "open_any", "list_sources",
    "SourceProtocol", "REGISTRY",
    "RESTSource", "OpenAlexSource", "GBIFSource", "NOAAClimateSource",
    "ArXivSource", "WikidataSPARQLSource", "FREDSource", "OpenMeteoSource",
    "GitHubSource", "OpenFDASource",
    "WebSocketSource", "KafkaSource", "MQTTSource", "SSESource",
    "FITSSource", "HDF5Source", "ParquetSource", "NetCDFSource",
    "FASTASource", "CSVStreamSource", "NDJSONSource",
    "PostgreSQLSource", "MongoDBSource", "SQLiteSource", "DuckDBSource", "InfluxDBSource",
]
