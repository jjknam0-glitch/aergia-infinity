"""
aergia.connectors.physics
~~~~~~~~~~~~~~~~~~~~~~~~~
High-energy physics, nuclear, and particle data archives.
CERN Open Data, HEPData, NNPDF, IceCube
"""
import random, math
from ..stream import from_iter, sfilter, smap

class _CERN:
    """CERN Open Data portal — LHC collision events."""
    def collisions(self, experiment="CMS", energy_tev=13.6, mock_rate=1000):
        rng = random.Random(42)
        def gen():
            for i in range(10_000_000):
                n_jets = rng.randint(0, 8)
                yield {"run": rng.randint(300_000, 360_000),
                       "event": i, "experiment": experiment,
                       "energy_tev": energy_tev,
                       "n_jets": n_jets,
                       "met": round(abs(rng.gauss(30, 50)), 1),
                       "n_muons": rng.randint(0, 4),
                       "n_electrons": rng.randint(0, 4),
                       "invariant_mass": round(abs(rng.gauss(90, 30)), 2),
                       "b_tags": rng.randint(0, min(n_jets, 4))}
        return from_iter(gen())

    def higgs_candidates(self, channel="H→ZZ→4l"):
        return sfilter(lambda e: e.get("n_muons", 0) >= 4 or e.get("n_electrons", 0) >= 4,
                       self.collisions())

class _IceCube:
    """IceCube Neutrino Observatory — neutrino event stream."""
    def events(self, energy_tev_min=1.0):
        rng = random.Random(99)
        def gen():
            for i in range(1_000_000):
                yield {"event_id": i, "time_mjd": 58000 + i*0.001,
                       "energy_tev": round(math.exp(rng.gauss(1, 2)), 3),
                       "zenith_deg": round(rng.uniform(0, 180), 2),
                       "azimuth_deg": round(rng.uniform(0, 360), 2),
                       "n_strings": rng.randint(1, 86),
                       "topology": rng.choice(["track","cascade","double_cascade"])}
        return from_iter(g for g in gen() if g["energy_tev"] >= energy_tev_min)

CERN    = _CERN()
IceCube = _IceCube()
